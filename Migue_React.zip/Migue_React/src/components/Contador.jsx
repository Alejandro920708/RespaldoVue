import React from 'react'
import reactDom from 'react-dom'

const Contador = () => {

    const [contador,setContador] =React.useState(0) 
    const aumentar = () =>{
        setContador(contador+1)
    }

    return (
        <div>
            <hr/>
            <h2>
                Contador
            </h2>
            <h3>numero numero aumentando: {contador}</h3>
            <h4>
                {
                    contador>2?'Es mayor a dos ':'Es menor a dos'
                }
            </h4>
            <button onClick={()=>aumentar()}>
                Click
            </button>
        </div>
    )
}

export default Contador
