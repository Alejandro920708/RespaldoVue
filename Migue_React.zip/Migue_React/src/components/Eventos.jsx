import React,{Fragment,useState} from 'react'



// const texto ='nuevo texto'
const Eventos = () => {

    const [texto,setTexto] = useState('Texto desde estado')

    const eventoClick=()=>{
        console.log('click al buttons');
        // texto='nuevo'
        setTexto('nuevo texto')
    }
    //Fragment para no usar div en cada return cada return debe retornar un solo elemento
    return (
        <Fragment>
            
            <hr/>
            <h2>Eventos</h2>
            <h2>{ texto }</h2>
            {/* <button onClick={()=>eventoClick()}>Click </button> */}
            <button onClick={()=>eventoClick()}>Click </button>
        </Fragment>
    )
}

export default Eventos
