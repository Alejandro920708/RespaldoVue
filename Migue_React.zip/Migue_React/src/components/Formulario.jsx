import React from 'react'

const Formulario = () => {

    const arregloFrutas = [
        //  {fruta:'Sandia', descripcion:'Fruta verde'},
        {id:1,fruta:'Sandia', descripcion:'Fruta verde'},
    ]

    const [fruta,setFruta]= React.useState('')
    const [descripcion,setDescripcion]= React.useState('')
    const [listaFrutas,setArregloFrutas]= React.useState(arregloFrutas)

    const actualizarArregloFrutas=(arreglo)=>{
        
     const nuevaLista= listaFrutas.map((item,index)=>{

            if(item.id===arreglo.id)
            {
                const itemActualizado={
                     ...item,
                        
                            id:arreglo.id,
                            fruta:arreglo.fruta,
                            descripcion:arreglo.descripcion
                        
                    };
                return itemActualizado;
            }
            return item;
        });
        
        setArregloFrutas(nuevaLista);
    }

    const guardarDatos=(e)=>{

        e.preventDefault(); 
        
        if(!fruta.trim())
        {
            console.log('esta vacio fruta')

            return 
        }
        if(!descripcion.trim())
        {
            console.log('esta vacio descripcion')

            return 
        }

        console.log('procesando datos...'+fruta+','+descripcion);
        setArregloFrutas(
            [
                ...listaFrutas,
                {id:(listaFrutas.length+2),fruta:fruta,descripcion:descripcion}
            ]);
        e.target.reset()
        setFruta('')
        setDescripcion('')
    }


    return (
        <div>
            <h2>Formulario</h2>
            {/* <form onSubmit={guardarDatos}>
                <input 
                type="text"
                placeholder="Ingresa Fruta"
                className="form-control mb-2"
                onChange={(e)=>setFruta(e.target.value)}
                />

                <input 
                type="text"
                placeholder="Ingrese Descripcion"
                className="form-control mb-2"
                onChange={(e)=>setDescripcion(e.target.value)}
                />
                <button className=" form-control btn btn-primary btn-block" type="submit">Agregar</button>

            </form> */}

            <form onSubmit={guardarDatos}>
            {    

                listaFrutas.map((item,index)=>(
                    <div key={item.id}>
                        <div className="row">
                            <div className="col-sm-6">
                            <input 
                                type="text"
                                placeholder="Ingresa Fruta"
                                className="form-control mb-2"
                                onChange={(e)=>actualizarArregloFrutas({id:item.id,fruta:e.target.value,descripcion:item.descripcion})}
                                value={item.fruta}
                                />
                            </div>
                            <div className="col-sm-6">
                            <input 
                                type="text"
                                placeholder="Ingrese Descripcion"
                                className="form-control mb-2"
                                onChange={(e)=>actualizarArregloFrutas({id:item.id,fruta:item.fruta,descripcion:e.target.value})}
                                value={item.descripcion}
                                />
                            </div>
                                
                        </div>
                    </div>
                ))
            }
            <h3>Agregar nuevo elemento </h3>
                <div className="row">
                    <div className="col-sm-6">
                        <input 
                        type="text"
                        placeholder="Ingresa Fruta"
                        className="form-control mb-2"
                        onChange={(e)=>setFruta(e.target.value)}
                        />

                        
                    </div>
                    <div className="col-sm-6">
                        <input 
                            type="text"
                            placeholder="Ingrese Descripcion"
                            className="form-control mb-2"
                            onChange={(e)=>setDescripcion(e.target.value)}
                            />
                    </div>
                </div>

                <button className=" form-control btn btn-primary btn-block" type="submit">Agregar</button>

            </form>
        </div>
    )
}

export default Formulario
