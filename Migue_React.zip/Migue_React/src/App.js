
// import Contador from './components/Contador';
// import Eventos from './components/Eventos';
// import Parrafo from './components/Parrafo'
// import Variables from './components/Variables'

import Formulario from "./components/Formulario";

// import Listas from './components/Listas';
function App() {
  return (
    <div className='container mt-5'>
     <h1>!Hola mundo react !</h1>
     {/* <Parrafo />
     <Variables/>
     <Eventos/>
     <Contador/> 
     <Listas/>
     */
     <Formulario/>
     }

    </div>
  );
}

export default App;
