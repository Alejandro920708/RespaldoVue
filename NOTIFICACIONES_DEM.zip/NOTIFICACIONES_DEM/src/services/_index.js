import Axios from 'axios';
import avanceService from './AvanceService';
import store from '../store/index'

// Axios configuration 
Axios.defaults.headers.common.Accept = 'application/json';
Axios.defaults.headers.common['Access-Control-Allow-Origin'] = '*';

export default {
    avanceService: new avanceService(Axios, `${ store.state.baseUrl }`),
}