export default (axios, baseUrl) => {

    return {       
        async ObtenerAvanceEmpresa(empresaId, ejercicio) {
            let respuesta;
            await axios
                .get(
                    `${baseUrl}api/Avance/ObtenerAvanceEmpresa?idEmpresa=${empresaId}&ejercicio=${ejercicio}`
                )
                .then((result) => {
                    respuesta = result.data;
                });
            return respuesta;
        },
        async ObtenerProgresoAvanceEmpresa(empresaId, ejercicio) {
            let respuesta;
            await axios
                .get(                   
                    `${baseUrl}api/Avance/ObtenerProgresoAvanceEmpresa?idEmpresa=${empresaId}&ejercicio=${ejercicio}`
                    )
                .then((result) => {
                    respuesta = result.data.key;
                });
            return respuesta;
        }
    }
}