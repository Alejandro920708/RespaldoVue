// import notificaciones from './../components/Notificaciones'

// export default [
//     { path: '/', name: 'notificaciones', component: notificaciones},   
// ]