<template>
  <div id="app">
   <!--<router-view></router-view>-->
    <Notificaciones/>
  </div>
</template>

<script>

import Notificaciones from './components/Notificaciones'

export default {
  name: 'App',
  components:{
    Notificaciones

  }
}
</script>
