<template>
  <div>
    <div>{{ label }}</div>
    <tree-menu
      v-for="node in nodes"
      :nodes="node.nodes"
      :label="node.label"
      :key="node.label"
    >
    </tree-menu>
  </div>
</template>
 <script>
export default {
  props: {
    label: String,
    nodes: Array,
  },
  name: "tree-menu"
 
};
</script>