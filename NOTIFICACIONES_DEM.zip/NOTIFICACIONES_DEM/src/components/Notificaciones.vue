<template>
  <div>
    <div class="container">
      <div class="col-md-12 mb-4">
        <div class="dropdown">
          <a
            @click="obtener()"
            class="btn m-auto py-1"
            style="color: black !important"
            href="#"
            role="button"
            id="dropdownMenuButton"
            data-toggle="dropdown"
            aria-haspopup="true"
            aria-expanded="false"
          >
            <div class="input-group">
              <div class="input-group-prepend m-auto">
                <i class="fas fa-th fa-2x"></i>
              </div>
            </div>
            <p>Mi avance</p>
          </a>
          <div class="dropdown-menu dropdown-menu-right avance">
            <h5>
              <p class="col-md-12">Tú avance de declaración anual</p>
            </h5>
            <div v-if="loading">
              <center>
                <img :src="$store.state.rutaImagen" width="350" height="300" />
              </center>
            </div>
            <form v-else class="px-4 py-3">
              <div class="form-group">
                <div v-for="(item, index) of respuesta.key" :key="index">
                  <span
                    :content="dependencias(item.avance.dependencia)"
                    v-tippy
                    :class="
                      !item.avance.tieneSubModulo && item.avance.estatus == 2
                        ? 'text-success'
                        : !item.avance.tieneSubModulo &&
                          item.avance.estatus == 1
                        ? 'text-warning'
                        : ''
                    "
                  >
                    {{ item.avance.indice + " " + item.avance.descripcion }}
                    <i
                      v-if="
                        !item.avance.tieneSubModulo && item.avance.estatus == 2
                      "
                      class="fas fa-check-circle"
                    ></i>
                    <i
                      v-else-if="
                        !item.avance.tieneSubModulo && item.avance.estatus == 1
                      "
                      class="fas fa-exclamation-circle"
                    ></i>
                  </span>

                  <Lista
                    :avancePrincipal="item.avance"
                    :avances="item.avances"
                    :avanceHijo="null"
                  />
                </div>
              </div>
              <div class="form-group">
                Tú progreso: {{ value }} / {{ max }}
                <div class="progress">
                  <div
                    class="progress-bar progress-bar-striped"
                    role="progressbar"
                    :style="`width: ${value}%`"
                    aria-valuemin="0"
                    :aria-valuemax="max"
                  ></div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Lista from "./Lista";

export default {
  name: "Notificaciones",
  components: {
    Lista,
  },
  data() {
    return {
      respuesta: [],
      filtro: [],
      value: 0,
      max: 100,
      animate: true,
      loading: true,
    };
  },
  methods: {
    async obtener() {
      let resultado1 = await this.$services.avanceService.ObtenerAvanceEmpresa(
        this.$store.state.empresaId,
        this.$store.state.ejercicio
      );
      this.respuesta = resultado1;
      this.loading = false;

      let resultado2 = await this.$services.avanceService.ObtenerProgresoAvanceEmpresa(
        this.$store.state.empresaId,
        this.$store.state.ejercicio
      );
      this.value = resultado2;
    },
    dependencias(parametro) {
      if (parametro.length > 0) {
        let cadena = "";
        for (let index = 0; index < parametro.length; index++) {
          cadena = parametro[index].descripcion + ", " + cadena;
        }
        return "Módulos dependientes: " + cadena;
      } else {
        return "No hay módulos dependientes";
      }
    },
  },
};
</script>

<style scoped>
.avance {
  width: 400px !important;
}
</style>
