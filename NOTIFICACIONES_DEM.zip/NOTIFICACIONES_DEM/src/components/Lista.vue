<template>
  <div>
    <div v-if="avancePrincipal != null">
      <ul v-if="avanceHijo != null">
        <span 
          :content="dependencias(avanceHijo.dependencia)" v-tippy        
          :class="
            !avanceHijo.tieneSubModulo && avanceHijo.estatus == 2
              ? 'text-success'
              : !avanceHijo.tieneSubModulo && avanceHijo.estatus == 1
              ? 'text-warning'
              : ''
          "
        >
          {{
            avanceHijo.nivel == 2
              ? avanceHijo.indice + " " + avanceHijo.descripcion
              : ""
          }}
          <i
            v-if="
              !avanceHijo.tieneSubModulo &&
              avanceHijo.estatus == 2 &&
              avanceHijo.nivel == 2
            "
            class="fas fa-check-circle"
          ></i>
          <i
            v-else-if="
              !avanceHijo.tieneSubModulo &&
              avanceHijo.estatus == 1 &&
              avanceHijo.nivel == 2
            "
            class="fas fa-exclamation-circle"
          ></i>
        </span>
        <ul v-if="avanceHijo != null">
          <span         
          :content="dependencias(avanceHijo.dependencia)" v-tippy
            :class="
              !avanceHijo.tieneSubModulo &&
              avanceHijo.estatus == 2 &&
              avanceHijo.nivel == 3
                ? 'text-success'
                : !avanceHijo.tieneSubModulo &&
                  avanceHijo.estatus == 1 &&
                  avanceHijo.nivel == 3
                ? 'text-warning'
                : ''
            "
          >
            {{
              avanceHijo.nivel == 3
                ? avanceHijo.indice + " " + avanceHijo.descripcion
                : ""
            }}
            <i
              v-if="
                !avanceHijo.tieneSubModulo &&
                avanceHijo.estatus == 2 &&
                avanceHijo.nivel == 3
              "
              class="fas fa-check-circle"
            ></i>
            <i
              v-else-if="
                !avanceHijo.tieneSubModulo &&
                avanceHijo.estatus == 1 &&
                avanceHijo.nivel == 3
              "
              class="fas fa-exclamation-circle"
            ></i>
          </span>
        </ul>
      </ul>
    </div>

    <lista
      v-for="avance in avances"
      :avancePrincipal="avance"
      :avanceHijo="avance.avance"
      :avances="avance.avances"
      :key="avance.avanceId"
    >
      {{ avance.avanceId }}
    </lista>
  </div>
</template>
 <script>
export default {
  props: {
    avances: Array,
    avancePrincipal: {
      type: Object,
      required: false,
    },
    avanceHijo: {
      type: Object,
      required: false,
    },
  },
  name: "lista",
  methods: {
    dependencias(parametro) {
      if (parametro.length > 0) {
        let cadena = "";
        for (let index = 0; index < parametro.length; index++) {
          cadena = parametro[index].descripcion + ", " + cadena;
        }
        return "Módulos dependientes: " + cadena;
      } else {
        return "No hay módulos dependientes";
      }
    },
  },
};
</script>