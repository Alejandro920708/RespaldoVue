import Vue from 'vue'
import App from './App.vue'
//import { BootstrapVue, IconsPlugin } from 'bootstrap-vue'
// Import Bootstrap an BootstrapVue CSS files (order is important)
//import 'bootstrap/dist/css/bootstrap.css'
//import 'bootstrap-vue/dist/bootstrap-vue.css'
//import VueRouter from 'vue-router'
//import routes from './routes/index'
import axios from 'axios'
import VueAxios from 'vue-axios'
import services from './services/_index'
import store from './store'
import VueTippy, { TippyComponent } from "vue-tippy";

Vue.use(VueTippy);

Vue.component("tippy", TippyComponent);

// Make BootstrapVue available throughout your project
//Vue.use(BootstrapVue)
// Optionally install the BootstrapVue icon components plugin
//Vue.use(IconsPlugin)

Vue.config.productionTip = false

//Router config
// Vue.use(VueRouter)
// let router = new VueRouter({
//   routes
// })

Vue.use(VueAxios, axios)

// Global logic methods
Vue.use({
  install(Vue) {
    Object.defineProperty(Vue.prototype, '$services', {
      value: services
    })
  }
})

new Vue({
  //router,
  store,
  render: h => h(App),
}).$mount('#appNotificaciones')
