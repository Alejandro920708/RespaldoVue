import Vue from 'vue'
//import VueRouter from 'vue-router'
//import routes from './routes/index'
import axios from 'axios'
import VueAxios from 'vue-axios'
import services from './services/_index'
import store from './store'
import Notificaciones from './components/Notificaciones'
import VueTippy, { TippyComponent } from "vue-tippy";


Vue.use(VueTippy);

Vue.component("tippy", TippyComponent);

Vue.config.productionTip = false

//Router config
// Vue.use(VueRouter)
// let router = new VueRouter({
//   routes
// })

Vue.use(VueAxios, axios)

// Global logic methods
Vue.use({
  install(Vue) {
    Object.defineProperty(Vue.prototype, '$services', {
      value: services
    })
  }
})

new Vue({
    //router,
    store,
    components:{
        Notificaciones, 
    }
  }).$mount('#appNotificaciones')
  
