export default (axios, baseUrl) => {

    return {       
        async ObtenerListaAplicacionesEmpresa(empresaId) {
            let respuesta;
            await axios
                .get(
                    `${baseUrl}api/AdministradorAplicaciones/ObtenerListaAplicacionesEmpresa?empresaId=${empresaId}`
                )
                .then((result) => {
                    respuesta = result.data;
                });
            return respuesta;
        }       
    }
}