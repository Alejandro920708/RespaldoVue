import Axios from 'axios';
import administradorAplicacionesService from './AdministradorAplicacionesService';
import store from '../store/index'

// Axios configuration 
Axios.defaults.headers.common.Accept = 'application/json';
Axios.defaults.headers.common['Access-Control-Allow-Origin'] = '*';

export default {
    administradorAplicacionesService: new administradorAplicacionesService(Axios, `${ store.state.baseUrl }`),
}