<template>
  <div id="app">
    <componente-lista-aplicaciones />
  </div>
</template>

<script>
import ComponenteListaAplicaciones from './components/ComponenteListaAplicaciones.vue'

export default {
  name: 'App',
  components: {
    ComponenteListaAplicaciones
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
