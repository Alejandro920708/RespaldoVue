import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    baseUrl: window.baseUrl,  
    baseUrlNotificaciones: window.baseUrlNotificaciones,  
    empresaId: window.empresaId,
    ejercicio: window.ejercicio,
    rutaImagen: window.rutaImagen
  },
  mutations: {
    // put sychronous functions for changing state e.g. add, edit, delete
  },
  actions: {
    // put asynchronous functions that can call one or more mutation functions
  }
})
