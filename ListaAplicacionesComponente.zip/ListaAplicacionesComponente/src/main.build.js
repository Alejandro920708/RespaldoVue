import Vue from 'vue'
import ComponenteListaAplicaciones from './components/ComponenteListaAplicaciones'

import axios from 'axios'
import VueAxios from 'vue-axios'
import services from './services/AdministradorAplicacionesService'
import store from './store'
import AOS from 'aos'
import 'aos/dist/aos.css'

Vue.config.productionTip = false

Vue.use(VueAxios, axios)
// Global logic methods
Vue.use({
  install(Vue) {
    Object.defineProperty(Vue.prototype, '$services', {
      value: services
    })
  }
})

new Vue({
  store,
  created () {
    AOS.init()
},
  components:{
    ComponenteListaAplicaciones, 
  }
}).$mount('#appComponenteListaAplicaciones')
  
