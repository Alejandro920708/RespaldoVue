<template>
    <div class="container mt-5">
      <div v-if="loading">
              <center>
                <img :src="$store.state.rutaImagen" />
              </center>
            </div>
      <div v-else class="row" align="center" justify="center">
          <div  data-aos="fade-up" class="col-md-4"
            v-for="aplicacion in aplicaciones"
                :key="aplicacion.notificacionesId" >
            <componente-aplicacion-v-4 :urlLogin="aplicacion.urlLogin" :logotipo="aplicacion.logotipo" :descripcion="aplicacion.descripcion" :titulo="aplicacion.titulo" :descripcionBreve="aplicacion.descripcionBreve" />
          </div>
      </div>
    </div>
</template>
<script>
import ComponenteAplicacionV4 from './ComponenteAplicacionV4.vue';
const signalR = require("@aspnet/signalr");
export default {
  components: {ComponenteAplicacionV4 },
  name: "ComponenteListaAplicaciones",
  data() {
    return {
      loading:true,
       aplicaciones: 
       [
        {
          aplicacionId:1,
          urlLogin: 'https://xpd.okta.com/home/centralpoint/0oaqca0srjxjKy70L5d6/aln17hj0tem2QNvln1d8',
          logotipo:'https://ok12static.oktacdn.com/fs/bcg/4/gfs17hj5g3573SRDD1d8',
          descripcion:'With supporting text below as a natural',
          descripcionBreve:'ContainerApp',
          titulo:'Okta'
        },
        {
          aplicacionId:2,
          urlLogin: 'https://xpd.okta.com/home/centralpoint/0oaqca0srjxjKy70L5d6/aln17hj0tem2QNvln1d8',
          logotipo:'https://xpd.mx/img/landing/CAFIDI-logo.webp',
          descripcion:'Somos un aplicativo que te facilitara la presentación de la declaración anual.',
          descripcionBreve:'Declaracion Anual',
          titulo:'Cafidi 2020'
        },
        {
          aplicacionId:3,
          urlLogin: 'https://xpd.okta.com/home/centralpoint/0oaqca0srjxjKy70L5d6/aln17hj0tem2QNvln1d8',
          logotipo:'https://xpd.mx/img/landing/CAFIDI-logo.webp',
          descripcion:'Somos un aplicativo que te facilitara la presentación de la declaración anual.',
          descripcionBreve:'Declaracion Anual',
          titulo:'Cafidi 2021'
        },
        {
          aplicacionId:4,
          urlLogin: 'https://xpd.okta.com/home/centralpoint/0oaqca0srjxjKy70L5d6/aln17hj0tem2QNvln1d8',
          logotipo:'https://xpd.mx/img/landing/CAFIDI-logo.webp',
          descripcion:'Somos un aplicativo que te facilitara la presentación de la declaración anual.',
          descripcionBreve:'Declaracion Anual',
          titulo:'Cafidi 2022'
        },
        {
          aplicacionId:5,
          urlLogin: 'https://xpd.okta.com/home/centralpoint/0oaqca0srjxjKy70L5d6/aln17hj0tem2QNvln1d8',
          logotipo:'https://basalcapital.mx/img/conelec.png',
          descripcion:'Reducción de tiempo, con la funcionalidad automática de carga y contabilidad de facturas en tiempo real.',
          descripcionBreve:'Contabilidad Online',
          titulo:'CIO'
        },
        {
          aplicacionId:6,
          urlLogin: 'https://xpd.okta.com/home/centralpoint/0oaqca0srjxjKy70L5d6/aln17hj0tem2QNvln1d8',
          logotipo:'https://basalcapital.mx/img/protectorfiscal.png',
          descripcion:'Somos una plataforma web dirigida a cualquier contribuyente y/o profesionista fiscal, que te alerta si tú o tus proveedores son considerados por el SAT ',
          descripcionBreve:'Lista negra',
          titulo:'Protector Fiscal'
        },
        {
          aplicacionId:7,
          urlLogin: 'https://xpd.okta.com/home/centralpoint/0oaqca0srjxjKy70L5d6/aln17hj0tem2QNvln1d8',
          logotipo:'https://basalcapital.mx/img/logo.png',
          descripcion:'Basal Capital cuenta con una sofisticada herramienta en línea para el manejo, procesamiento y control del pago de las nóminas',
          descripcionBreve:'Nomina',
          titulo:'Plataforma Nómina'
        },
        {
          aplicacionId:8,
          urlLogin: 'https://xpd.okta.com/home/centralpoint/0oaqca0srjxjKy70L5d6/aln17hj0tem2QNvln1d8',
          logotipo:'https://basalcapital.mx/img/xpd.png',
          descripcion:'XPD es un Proveedor Autorizado de Certificación (PAC) que se adapta dependiendo de las necesidades de la empresa',
          descripcionBreve:'Facturacion',
          titulo:'XPD Factura'
        },
        {
          aplicacionId:9,
          urlLogin: 'https://xpd.okta.com/home/centralpoint/0oaqca0srjxjKy70L5d6/aln17hj0tem2QNvln1d8',
          logotipo:'https://i.imgur.com/42SqVZd.png',
          descripcion:'Use dropbox to sync your photos to our platform and share it with others.',
          descripcionBreve:'Filestorage',
          titulo:'Dropbox'
        },
        {
          aplicacionId:10,
          urlLogin: 'https://xpd.okta.com/home/centralpoint/0oaqca0srjxjKy70L5d6/aln17hj0tem2QNvln1d8',
          logotipo:'https://i.imgur.com/S5oK3Oe.png',
          descripcion:'Developing products for developers,project managers and architects.',
          descripcionBreve:'Salesforce',
          titulo:'Project management'
        },
        {
          aplicacionId:11,
          urlLogin: 'https://xpd.okta.com/home/centralpoint/0oaqca0srjxjKy70L5d6/aln17hj0tem2QNvln1d8',
          logotipo:'https://i.imgur.com/S2In5pz.png',
          descripcion:'Developing products for developers,project managers and architects.',
          descripcionBreve:'Atlassian',
          titulo:'Project management'
        },
        {
          aplicacionId:12,
          urlLogin: 'https://xpd.okta.com/home/centralpoint/0oaqca0srjxjKy70L5d6/aln17hj0tem2QNvln1d8',
          logotipo:'https://i.imgur.com/lXEUCY8.png',
          descripcion:'Sell you items with ease with having any website with our free platform',
          descripcionBreve:'Ecommerce',
          titulo:'Shopify'
        },
        {
          aplicacionId:13,
          urlLogin: 'https://xpd.okta.com/home/centralpoint/0oaqca0srjxjKy70L5d6/aln17hj0tem2QNvln1d8',
          logotipo:'https://i.imgur.com/lXEUCY8.png',
          descripcion:'Sell you items with ease with having any website with our free platform',
          descripcionBreve:'Ecommerce',
          titulo:'Shopify'
        },
        {
          aplicacionId:14,
          urlLogin: 'https://xpd.okta.com/home/centralpoint/0oaqca0srjxjKy70L5d6/aln17hj0tem2QNvln1d8',
          logotipo:'https://i.imgur.com/42SqVZd.png',
          descripcion:'Use dropbox to sync your photos to our platform and share it with others.',
          descripcionBreve:'Filestorage',
          titulo:'Dropbox'
        },
     ],
     bootstrapColWidth:12,
     numOfCols:4,
     rowCount:0
    };
  },
  methods: {
    async ObtenerListaAplicacionesEmpresa() {
      this.notificaciones = [];
        await this.$services.administradorAplicacionesService.ObtenerListaAplicacionesEmpresa(
        this.$store.state.empresaId,
      );
    },
     callFunction: function () {
          var v = this;
            setTimeout(function () {
              v.loading = false;
              console.log("End");
            }, 1500);
        }
  },
  created: async function () {
    this.connection = new signalR.HubConnectionBuilder()
      .withUrl(this.$store.state.baseUrlNotificaciones)
      .build();
      this.rowCount= (this.bootstrapColWidth/this.numOfCols)
  },
  mounted: function () {
    this.callFunction();
  }
};
</script>
<style scoped>
#app {
    /* background: #eee */
    background-color: #efefef;
}
</style>