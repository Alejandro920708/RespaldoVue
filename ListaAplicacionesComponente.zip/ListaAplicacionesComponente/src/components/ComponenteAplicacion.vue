<template>
      <div class="none">
          <a aria-label="iniciar la aplicación Centralpoint" class="chiclet a--no-decoration" data-se="app-card" draggable="true"  data-toggle="modal" data-target="#myModal">
          <div class="card">
                <div class="card-header">
                    <div class="offset-10 col-md-2 mb-2">
                        <svg class="chiclet--action-kebab" width="20" height="6" viewBox="0 0 20 4" fill="#B7BCC0" xmlns="http://www.w3.org/2000/svg"><circle cx="2" cy="2" r="2"></circle><circle cx="10" cy="2" r="2"></circle><circle cx="18" cy="2" r="2"></circle></svg>
                    </div>
                </div>
                <div class="card-body">
                    <img class="chiclet--main-logo w-100" :src="logotipo" alt="Logotipo de empresa">
                    <p class="card-text chiclet--app-title">{{descripcion}}</p>
                </div>
                </div>
        </a>
      </div>
</template>
<script>
export default {
 name: "ComponenteAplicacion",
 props: ['urlLogin','logotipo','descripcion'],
 
}
</script>
<style scoped>
a { color: inherit; } 
.chiclet--main .chiclet--main-logo 
{
    max-height: 60px;
    max-width: 100%;
    flex-shrink: 0;
}
.a--no-decoration {
    text-decoration: none;
}
.chiclet--footer .chiclet--app-title {
    margin: 0;
    max-width: 100%;
    color: #212126 !important;
    font-size: .87055rem;
    font-weight: 400;
    overflow: hidden;
    max-height: 2.08932rem;
}
.chiclet--action-kebab{
   max-height:6;
   min-height:6;
}
</style>