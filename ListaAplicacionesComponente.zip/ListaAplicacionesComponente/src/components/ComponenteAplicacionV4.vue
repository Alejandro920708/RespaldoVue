<template>
            <div class="card p-3">
                <div class="d-flex flex-row mb-3">
                    <div class="w-25 ecosystem-logo" width="25">
                        <img :src="logotipo" class="img-fluid max-width: 100% card-img-top" >
                    </div>
                    <div class="d-flex flex-column ml-2">
                            <span><strong>{{titulo}}</strong></span>
                            <span class="text-black-50 badge badge-primary">{{descripcionBreve}}</span>
                            <span class="ratings">
                            </span>
                        </div>
                </div>
                <!-- <h6>{{descripcion}}</h6> -->
                <div class="descripcion">{{descripcion}}</div>
                <div class="d-flex justify-content-between install mt-3"><span>Installed 172 times</span><span class="text-primary"><a :href="urlLogin">Acceder&nbsp;</a> <i class="fa fa-angle-right"></i></span></div>
            </div>
</template>
<script>
export default {
 name: "ComponenteAplicacionV3",
 props: ['urlLogin','logotipo','descripcion','titulo','descripcionBreve'],
}
</script>
<style scoped>
.badge-primary
{
    background: cornflowerblue;
}
.card {
  display: block;
    margin-bottom: 20px;
    line-height: 1.42857143;
    background-color: #fff;
    /* background-color: #46a37a;; */
    /* background-color: #efefef; */
    border-radius: 2px;
    box-shadow: 0 2px 5px 0 rgba(0,0,0,0.16),0 2px 10px 0 rgba(0,0,0,0.12);
    transition: box-shadow .25s,transform .2s;
}
.card:hover {
  box-shadow: 0 8px 17px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
}


.ratings i {
    color: green
}

.install span {
    font-size: 12px
}

.col-md-4 {
    margin-top: 27px
}
.card:hover {
    transform: scale(1.1);
}
.descripcion
{
    font-size: 13px;
}
/* .card-img-top{
    width: 6vw;
    height: 6vw;
    object-fit: cover;
} */
</style>