<template>
            <div class="card p-3">
                <div class="d-flex flex-row mb-3">
                    <div class="w-25" width="25">
                        <img :src="logotipo" class="img-fluid max-width: 100%" >
                    </div>
                    <div class="d-flex flex-column ml-2"><span>{{titulo}}</span><span class="text-black-50">{{descripcionBreve}}</span><span class="ratings"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></span></div>
                </div>
                <h6>{{descripcion}}</h6>
                <div class="d-flex justify-content-between install mt-3"><span>Installed 172 times</span><span class="text-primary"><a :href="urlLogin">Ver&nbsp;</a> <i class="fa fa-angle-right"></i></span></div>
            </div>
</template>
<script>
export default {
 name: "ComponenteAplicacionV3",
 props: ['urlLogin','logotipo','descripcion','titulo','descripcionBreve'],
}
</script>
<style scoped>
.card {
  display: block;
    margin-bottom: 20px;
    line-height: 1.42857143;
    background-color: #fff;
    border-radius: 2px;
    box-shadow: 0 2px 5px 0 rgba(0,0,0,0.16),0 2px 10px 0 rgba(0,0,0,0.12);
    transition: box-shadow .25s;
}
.card:hover {
  box-shadow: 0 8px 17px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
}
body {
    background: #eee
}

.ratings i {
    color: green
}

.install span {
    font-size: 12px
}

.col-md-4 {
    margin-top: 27px
}
</style>