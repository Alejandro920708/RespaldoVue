<template>
  <div>
    <div class="container">
      <div class="col-md-12 mb-4">
        <div class="dropdown">
          <a
            class="btn m-auto py-1"
            style="color: black !important"
            href="#"
            role="button"
            id="dropdownMenuButton"
            data-toggle="dropdown"
            aria-haspopup="true"
            aria-expanded="false"
            @click="ObtenerNotificaciones()"
          >
            <div class="input-group">
              <div class="input-group-prepend m-auto">
                <i class="fas fa-bell fa-2x"></i>
                <h6>
                  <span class="badge badge-danger">{{ contador }}</span>
                </h6>
              </div>
            </div>
            <p>Notificaciones</p>
          </a>
          <div
            class="dropdown-menu dropdown-menu-right componenteNotificaciones"
            style="height: 400px; overflow-y: scroll"
            ref="input"
          >
            <div v-if="notificaciones.length === 0" style="height: 100px">
              <p></p>
              <p class="text-center align-middle">
                No hay notificaciones disponibles
              </p>
            </div>
            <div
              class="list-group"
              v-for="notificacion in notificaciones"
              :key="notificacion.notificacionesId"
              v-else
            >
              <div class="card">
                <div class="card-body">
                  <h5 class="card-title">
                    {{ notificacion.titulo }}
                    <span v-if="!notificacion.visto" class="badge badge-info"
                      >Nueva</span
                    >
                  </h5>
                  <p>{{ notificacion.descripcion }}</p>
                  <p>
                    <time-ago
                      :datetime="notificacion.fechaCarga"
                      refresh
                      :locale="locale"
                      :long="longString"
                    />
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import TimeAgo from "vue2-timeago";
const signalR = require("@aspnet/signalr");

export default {
  name: "Notificaciones",
  components: {
    TimeAgo,
  },
  data() {
    return {
      hasfocus: false,
      contador: 0,
      notificaciones: [],
      locale: "es",
      longString: true,
      options: [
        { value: "en", label: "English (en)" },
        { value: "zh_TW", label: "繁體中文 (zh_TW)" },
        { value: "zh_CN", label: "简体中文 (zh_CN)" },
        { value: "jp", label: "日本語 (jp)" },
        { value: "pt_BR", label: "Portugal(Brazil)" },
        { value: "es", label: "Spain" },
        { value: "ar", label: "Arabia" },
        { value: "fr", label: "French" },
        { value: "tr", label: "Turkish" },
        { value: "pl", label: "Polish" },
        { value: "id", label: "Indonesian" },
        { value: "ro", label: "Romanian" },
        { value: "ru", label: "Russian" },
        { value: "de", label: "Germany" },
        { value: "uk", label: "Ukrainian" },
        { value: "bg", label: "Bulgarian" },
      ],
    };
  },
  methods: {
    setFocus: function () {
      // Note, you need to add a ref="input" attribute to your input.
      this.$refs.input.focus();
    },
    async ObtenerNotificaciones() {
      this.notificaciones = [];

      let resultado = await this.$services.notificacionesService.ObtenerNotificaciones(
        this.$store.state.empresaId,
        this.$store.state.ejercicio
      );

      this.notificaciones = resultado.key;      

      await this.$services.notificacionesService.ActualizarNotificaciones(
        this.$store.state.empresaId,
        this.$store.state.ejercicio
      );

      let resultado2 = await this.$services.notificacionesService.ObtenerContadorNotificaciones(
        this.$store.state.empresaId,
        this.$store.state.ejercicio
      );
      this.contador = resultado2.key;
    },
    async conectar(conn) {
      conn
        .start()
        .then(() =>
          conn.invoke(
            "UnirAGrupo",
            this.$store.state.empresaId,
            this.$store.state.ejercicio
          )
        );

      this.connection.on("ObtenerContadorNotificacion", async () => {
        let resultado = await this.$services.notificacionesService.ObtenerContadorNotificaciones(
          this.$store.state.empresaId,
          this.$store.state.ejercicio
        );
        this.contador = resultado.key;
      });
    },
  },
  created: async function () {
    this.connection = new signalR.HubConnectionBuilder()
      .withUrl(this.$store.state.baseUrlNotificaciones)
      .build();

    let resultado = await this.$services.notificacionesService.ObtenerContadorNotificaciones(
      this.$store.state.empresaId,
      this.$store.state.ejercicio
    );
    this.contador = resultado.key;
  },
  mounted: function () {
    this.conectar(this.connection);

    this.connection.onclose(() => {
      this.conectar(this.connection);
    });
  },
};
</script>

<style scoped>
.componenteNotificaciones {
  width: 400px !important;
  padding: 0rem 0 !important;
}
</style>
