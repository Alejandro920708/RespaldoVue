import Axios from 'axios';
import notificacionesService from './NotificacionesService';
import store from '../store/index'

// Axios configuration 
Axios.defaults.headers.common.Accept = 'application/json';
Axios.defaults.headers.common['Access-Control-Allow-Origin'] = '*';

export default {
    notificacionesService: new notificacionesService(Axios, `${ store.state.baseUrl }`),
}