
export default (axios, baseUrl) => {

    return {       
        async ObtenerContadorNotificaciones(empresaId, ejercicio) {
            let respuesta;
            await axios
                .get(
                    `${baseUrl}api/Notificaciones/ObtenerContadorNotificaciones?empresaId=${empresaId}&ejercicio=${ejercicio}`
                )
                .then((result) => {
                    respuesta = result.data;
                });
            return respuesta;
        },
        async ObtenerNotificaciones(empresaId, ejercicio) {
            let respuesta;
            await axios
                .get(
                    `${baseUrl}api/Notificaciones/ObtenerNotificaciones?empresaId=${empresaId}&ejercicio=${ejercicio}`
                )
                .then((result) => {
                    respuesta = result.data;
                });
            return respuesta;
        },
        async ActualizarNotificaciones(empresaId, ejercicio) {
            let respuesta;
            await axios
                .get(
                    `${baseUrl}api/Notificaciones/ActualizarNotificaciones?empresaId=${empresaId}&ejercicio=${ejercicio}`
                )
                .then((result) => {
                    respuesta = result.data;
                });
            return respuesta;
        }
    }
}