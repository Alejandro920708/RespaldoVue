import Vue from 'vue'
import ComponenteNotificaciones from './components/ComponenteNotificaciones'

import axios from 'axios'
import VueAxios from 'vue-axios'
import services from './services/_index'
import store from './store'


Vue.config.productionTip = false

Vue.use(VueAxios, axios)

// Global logic methods
Vue.use({
  install(Vue) {
    Object.defineProperty(Vue.prototype, '$services', {
      value: services
    })
  }
})

new Vue({
  //router,
  store,
  components:{
    ComponenteNotificaciones, 
  }
}).$mount('#appComponenteNotificaciones')
  
