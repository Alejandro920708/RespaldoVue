<template>
  <div id="app">
    
    <ComponenteNotificaciones />
  </div>
</template>   

<script>
import ComponenteNotificaciones from './components/ComponenteNotificaciones.vue'

export default {
  name: 'App',
  components: {
    ComponenteNotificaciones
  }
}
</script>
