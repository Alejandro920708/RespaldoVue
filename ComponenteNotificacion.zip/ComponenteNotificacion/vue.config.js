//const { BIconTypeUnderline } = require("bootstrap-vue");

module.exports = {
    runtimeCompiler:true,
    devServer: {
      proxy: 'http://localhost:8080'
    }
  }
  
