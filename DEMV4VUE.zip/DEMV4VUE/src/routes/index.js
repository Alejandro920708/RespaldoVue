import tipoReporte from './../components/TipoReporte'
import detallePoliza from './../components/DetallePoliza'
import detalleTransaccion from './../components/DetalleTransaccion'
import signalr from './../components/Signalr'
import infiniteScroll from './../components/InfiniteScroll'
import sumaTabla from './../components/SumaTabla'
import creditosDeudas from './../components/CreditosDeudas'
import detallesCreditosDeudas from './../components/DetalleCreditosDeudas'

export default [
    { path: '/TiporReporte', name: 'TiporReporte', component: tipoReporte, props: { empresaId: window.empresaId, ejercicio:window.ejercicio } } ,
    { path: '/detallePoliza/:periodo/:empresaId/:ejercicio', name: 'DetallePoliza', component: detallePoliza },
    { path: '/detalleTransaccion/:idPoliza/:periodo/:empresaId/:ejercicio', name: 'DetalleTransaccion',component:detalleTransaccion},
    { path: '/signalr', name: 'Signalr', component: signalr },
    { path: '/infiniteScroll', name: 'InfiniteScroll', component: infiniteScroll } ,   
    { path: '/sumaTabla', name: 'SumaTabla', component: sumaTabla } ,   
    { path: '/CreditosDeudas', name: 'CreditosDeudas', component: creditosDeudas, props: { empresaId: window.empresaId, ejercicio:window.ejercicio,tipoReporte:window.tipoReporte } } ,
    { path: '/', name: '' } ,
    { path: '/DetalleCreditosDeudas/:numeroCuenta/:periodo', name: 'DetalleCreditosDeudas', component: detallesCreditosDeudas, props: { empresaId: window.empresaId, ejercicio:window.ejercicio,tipoReporte:window.tipoReporte } } ,
    {
        path: '/AjusteAnual/AjusteAnual',
        beforeEnter() {
            // Put the full page URL including the protocol http(s) below
            window.location.replace(window.baseUrl+"AjusteAnual/AjusteAnual")
        }
    }
]