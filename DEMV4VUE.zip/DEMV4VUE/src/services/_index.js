import Axios from 'axios';
import demService from './DemService.js';
import polizaService from './PolizaService.js';
import empresaService from './EmpresaService.js';
import ajusteAnualService from './AjusteAnualService.js';

// Axios configuration 
Axios.defaults.headers.common.Accept = 'application/json';
Axios.defaults.headers.common['Access-Control-Allow-Origin'] = '*';


export default {
    demService: new demService(Axios, window.baseUrl),
    polizaService: new polizaService(Axios, window.baseUrl),
    empresaService: new empresaService(Axios, window.baseUrl),
    ajusteAnualService: new ajusteAnualService(Axios, window.baseUrl)
}