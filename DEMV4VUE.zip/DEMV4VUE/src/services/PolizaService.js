export default (axios, baseUrl) => {
    return {
        ObtenerPeriodos(tipoReporte, periodoInicio, periodoFin, accion, periodo) {
            return axios.get(`${baseUrl}api/polizas/ObtenerPeriodos?tipoReporte=${tipoReporte}&periodoInicio=${periodoInicio}&periodoFin=${periodoFin}&accion=${accion}&periodo=${periodo}`)
        },
        ObtenerTiposReporte() {
            return axios.get(`${baseUrl}api/polizas/ObtenerTiposReporte`)
        },
        LlamarCargaXMLPoliza(Chunk, FileName, rfcEmpresa, periodoCarga,ejercicio) {
            var FD = new FormData();
            FD.append('file', Chunk, FileName);
            FD.append('rfcEmpresa', rfcEmpresa);
            FD.append('periodoCarga', periodoCarga);
            FD.append('ejercicio', ejercicio);
            return axios.post(`${baseUrl}api/polizas/CargarXMLPoliza`, FD)
        },
        InicioProcesoPoliza(ruta, rfcEmpresa, periodoCarga, idEmpresa, ejercicio){
            return axios.post(`${baseUrl}api/polizas/ProcesoPolizas?rutaArchivo=${ruta}&idEmpresa=${idEmpresa}&periodo=${periodoCarga}&rfc=${rfcEmpresa}&ejercicio=${ejercicio}`, null)
        },
        ObtenerPaginacionPolizas(empresaId, ejercicio, periodo, omite, toma) {
            return axios.get(`${baseUrl}api/polizas/ObtenerPaginacionPolizas?empresaId=${empresaId}&ejercicio=${ejercicio}&periodo=${periodo}&omite=${omite}&toma=${toma}`)
        },
        
        ObtenerPaginacionTransacciones(polizaId,empresaId, ejercicio, periodo, omite, toma) {
            return axios.get(`${baseUrl}api/polizas/ObtenerPaginacionTransacciones?polizaId=${polizaId}empresaId=${empresaId}&ejercicio=${ejercicio}&periodo=${periodo}&omite=${omite}&toma=${toma}`)
        },
        ObtenerNotificacionesCargaPoliza(empresaId, ejercicio, periodo){
            return axios.get(`${baseUrl}api/polizas/ObtenerNotificacionesCargaPoliza?empresaId=${empresaId}&ejercicio=${ejercicio}&periodo=${periodo}`)
        }
    }
}