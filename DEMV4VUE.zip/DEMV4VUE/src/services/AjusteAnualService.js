export default (axios, baseUrl) => {

    return {
        ObtenerTotalPeriodosDeudasCreditos(empresaId, ejercicio,tipoSaldo) {
            return axios.get(`${baseUrl}api/AjusteAnual/ObtenerTotalPeriodosDeudasCreditos?empresaId=${empresaId}&ejercicio=${ejercicio}&tipoSaldo=${tipoSaldo}`)
        },
        async ObtenerTotalCuentasCreditosDeudas(empresaId,ejercicio,numeroCuenta,periodo,toma,omite){
            return await axios.get(`${baseUrl}api/AjusteAnual/ObtenerTotalCuentasCreditosDeudas?empresaId=${empresaId}&ejercicio=${ejercicio}&periodo=${periodo}&numeroCuenta=${numeroCuenta}&periodo=${periodo}&toma=${toma}&omite=${omite}`)
        },
        ActualizarDetalleCreditosDeudas(parametros,empresaId,ejercicio){
            return axios.post(`${baseUrl}api/AjusteAnual/ActualizarDetalleCreditosDeudas?empresaId=${empresaId}&ejercicio=${ejercicio}`,parametros)
        },
        ActualizarTotalPeriodoCreditosDeudas(parametros,empresaId,ejercicio,tipoSaldo,sumaTotales){
            return axios.post(`${baseUrl}api/AjusteAnual/ActualizarTotalPeriodoCreditosDeudas?empresaId=${empresaId}&ejercicio=${ejercicio}&tipoSaldoCreditosDeudas=${tipoSaldo}&TotalSaldoCreditosDeudas=${sumaTotales}`,parametros)
        },
        ObtenerRangoMeses(empresaId,ejercicio){
            return axios.get(`${baseUrl}api/AjusteAnual/ObtenerRangoMeses?empresaId=${empresaId}&ejercicio=${ejercicio}`)
        },
        ObtenerCatalogoTipoCambioporEjercicio(ejercicio){
            return axios.get(`${baseUrl}api/TipoCambio/ObtenerCatalogoTipoCambioporEjercicio?ejercicio=${ejercicio}`)
        },
        ObtenerParametrosAjusteAnual(empresaId,ejercicio,anexoId){
            return axios.get(`${baseUrl}api/Parametros/ObtenerParametrosRespuestaPorAnexoId?ejercicio=${ejercicio}&empresaId=${empresaId}&anexoId=${anexoId}`)
        },

    }

}