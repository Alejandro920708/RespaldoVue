export default (axios, baseUrl) => {
    return {
        ObtenerEmpresaPorId(empresaId) {
            return axios.get(`${baseUrl}api/empresa/ObtenerEmpresaPorId?empresaId=${empresaId}`)
        },
    }
}