export default (axios, baseUrl) => {
    return {
        ObtenerTipoReporte(empresaId, ejercicio) {
            return axios.get(`${baseUrl}api/dem/ObtenerTipoReporte?empresaId=${empresaId}&ejercicio=${ejercicio}`)
        },
        GuardarTipoReporte(parametros){
            return axios.post(`${baseUrl}api/dem/GuardarTipoReporte`,parametros)
        },
        ObtenerHistorial(empresaId, ejercicio) {
            return axios.get(`${baseUrl}api/dem/ObtenerHistorial?empresaId=${empresaId}&ejercicio=${ejercicio}`)
        }
    }
}