import * as signalR from '@aspnet/signalr';

export default {
    install(Vue) {
        Vue.prototype.$conexionSignalr = new signalR.HubConnectionBuilder()
            .withUrl(window.baserUrlHub)
            //.withAutomaticReconnect()
            .build();
        Vue.prototype.$estadoConexionSignalr = signalR.HubConnectionState.Connected;
    }
}