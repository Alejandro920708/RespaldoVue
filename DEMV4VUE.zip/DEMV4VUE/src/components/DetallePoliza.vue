<template>
  <div>
    <div class="container">
      <div class="row">
        <div class="col-md-12 mb-2 mt-5">
          <router-link
            :to="{
              name: 'TiporReporte',
              params: { empresaId: empresaId, ejercicio: ejercicio },
            }"
          >
            <i class="fas fa-arrow-alt-circle-left fa-2x"></i>
          </router-link>
        </div>
        <div class="col-md-12 list-group mb-5 mt-1">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th scope="col">Fecha</th>
                <th scope="col">Número Único de identificación de la póliza</th>
                <th scope="col">Concepto</th>
                <th scope="col">Acciones</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="poliza in polizas" :key="poliza.idpolizaArchivo">
                <td>{{ poliza.fecha }}</td>
                <td>{{ poliza.numUnIdenPol }}</td>
                <td>{{ poliza.concepto }}</td>
                <td>
                  <router-link
                    :to="`/detalleTransaccion/${poliza.idpolizaArchivo}/${periodo}/${empresaId}/${ejercicio}`"
                  >
                    <a href="" class="btn btn-primary polizas w-100"
                      ><i class="fas fa-file-invoice"></i
                    ></a>
                  </router-link>
                </td>
              </tr>
            </tbody>
          </table>
          <infinite-loading @infinite="infiniteHandler">
            <span slot="no-more"> No hay pólizas para mostrar </span>
          </infinite-loading>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import InfiniteLoading from "vue-infinite-loading";

export default {
  name: "DetallePoliza",
  props: {},
  components: {
    InfiniteLoading,
  },
  data() {
    return {
      omite: 0,
      toma: 0,
      periodo: 0,
      empresaId: 0,
      ejercicio: 0,
      polizas: [],
    };
  },
  methods: {
    infiniteHandler($state) {
      this.$services.polizaService
        .ObtenerPaginacionPolizas(
          this.empresaId,
          this.ejercicio,
          this.periodo,
          this.omite,
          this.toma
        )
        .then((r) => {
          r.data.key.poliza.forEach((p) => {
            this.polizas.push(p);
          });
          this.omite = this.omite + this.toma;
          this.toma = 10;
          $state.loaded();
        })
        .catch((r) => {
          if (r.response.status) {
            $state.complete();
          }
        });
    },
  },
  mounted() {
    this.omite = 0;
    this.toma = 10;
    if (this.$route.params.periodo) {
      this.periodo = this.$route.params.periodo;
      this.empresaId = this.$route.params.empresaId;
      this.ejercicio = this.$route.params.ejercicio;
    }
  },
};
</script>

<style>
    thead th {
        background-color: #2C3E50;
        color: white;
    }

    td.details-control {
        background: url('https://datatables.net/examples/resources/details_open.png') no-repeat center center;
        cursor: pointer;
    }

    tr.shown td.details-control {
        background: url('https://datatables.net/examples/resources/details_close.png') no-repeat center center;
    }

    tfoot tr {
        background-color: #2C3E50;
        color: white;
    }

    .detalle-PT .detalle-row {
        cursor: pointer;
        font-size: 13px;
    }

    .detalle-PT {
        cursor: pointer;
    }

    .tippy-tooltip.basal-theme {
        background: rgb(191,173,77);
    }
</style>