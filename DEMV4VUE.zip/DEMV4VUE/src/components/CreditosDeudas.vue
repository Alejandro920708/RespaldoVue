<template>
  <div>
    <b-container>
      <b-row>
        <b-col cols="1">
           <div style="height: 50px; margin-top: 10px;">  
                 <a href="/AjusteAnual/AjusteAnual">
                    <i class="fas fa-arrow-alt-circle-left fa-2x">
                    </i>
                 </a>
            </div>
        </b-col>
          <b-col cols="6" offset="2">
                   
                      <b-alert
                        :variant="tipoAlerta"
                        dismissible=""
                        fade=""
                        :show="mostrarMensaje"
                        @dismissed="mostrarMensaje=false"
                      >
                      <p class="text-center">{{mensaje}} mensaje </p>
                      </b-alert>
                  </b-col>
      </b-row>
      <b-row>
        <b-col cols="3" offset="9">
          <div style="margin-top:10%;margin-bottom:10%">

              <b-button 
                variant="primary" pill=""
                @click="ObtenerTipocambio()" > 
                Catálogo tipo de cambio
              </b-button> 
          </div>
        </b-col>
      </b-row>

      <!-- Tabla mensual datos pt creditos/deudas -->
      <b-row>
        <div style="height: 88vh; overflow: auto;">
          <table class="table table-bordered headerEstatico">
              <thead>
               <tr>
                 <th scope="col" class="text-center">Código agrupador</th>
                 <th scope="col" class="text-center">Concepto</th>
                 <th v-for="mes in Meses" :key="mes">
                    {{mes}}
                 </th>
                 <th scope="col" class="text-center"> Total </th>
                 <th scope="col" class="text-center">Activo</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="reg in totales" :key="reg.numeroCuenta">
                    <td>{{reg.codigoAgrupador}}</td>
                    <td>{{reg.descripcion}}</td>
                    <td v-for="total in reg.totalPeriodos" :key="total.key" :id="`tooltip-target-${reg.numeroCuenta}-${total.key}`">
                        <span v-if="reg.activo">
                          <b-tooltip :target="`tooltip-target-${reg.numeroCuenta}-${total.key}`" triggers="hover" placement="botton">
                            <router-link 
                            class="linkDetalleCuenta"
                              :to="`/DetalleCreditosDeudas/${reg.numeroCuenta}/${total.key}`"
                              >
                                <strong> Ver Detalle</strong>
                                {{total.value|currencidecimal}}
                            </router-link>
                          </b-tooltip>
                          {{total.value|currencidecimal}}
                        </span>
                        <span v-else>
                          $0
                        </span>
                    </td>
                    <td>{{reg.totalFinalCuenta|currencidecimal}}</td>
                    <td><input type="checkbox" class="inputCheck" v-model="reg.activo" @change="CalcularActualizarTotalesPorMes(reg)"></td>
                </tr>
              </tbody>
              <tfoot class="footerEstatico">
                <tr>
                  <td scope="row" :colspan="(2+Meses.length)" class="text-right">Total</td>
                  <td scope="row" colspan="2">{{sumaTotales|currencidecimal}}</td>
                </tr>
              </tfoot>
          </table>

        </div>
      </b-row>
      <!-- ///////Final Tabla mensual datos pt creditos/deudas -->

      <b-modal ref="modal-tipoCambio" hide-footer title="Tipos de cambio">
        <b-table
          striped
          hover
          bordered
          :items="tiposCambio"
          :fields="fields"
        ></b-table>
      </b-modal>
    </b-container>
  </div>
</template>

<script>
export default {
  name: "CreditosDeudas",
  props: {
    empresaId: Number,
    ejercicio: Number,
    periodo:Number,
    tipoReporte: String,
    periodoInicio: Number,
    periodoFin: Number,
    temporal:[]
  },
  components: {},
  data() {
    return {
      loading: false,
      busquedaNumCta: "",
      totales: [],
      sumaTotales: 0,
      tiposCambio: [],
      Meses: ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"],
      MesesCambio: ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"],
      mensaje: "",
      mostrarMensaje: false,
      dismissSecs: 15,
      dismissCountDown: 0,
      tipoAlerta: "",
      fields: [{
          key: "mes",
          label: "Periodo"
      }, {
          key: "tipoCambio",
          label: "Tipo Cambio"
      }]
    };
  },
  filters:{
    currencidecimal(e, t, o){
      var a = /(\d{3})(?=\d)/g;
      if (e = parseFloat(e), !isFinite(e) || !e && 0 !== e) return "";
      t = null != t ? t : "$", o = null != o ? o : 2;
      var i = Math.abs(e).toFixed(o),
          r = o ? i.slice(0, -1 - o) : i,
          s = r.length % 3,
          n = s > 0 ? r.slice(0, s) + (r.length > 3 ? "," : "") : "",
          c = o ? i.slice(-1 - o) : "",
          l = e < 0 ? "-" : "";
      return l + t + n + r.slice(s).replace(a, "$1,") + c
    }
  },
  methods: {
    sortedArray(e){
      return e.sort((function (e, t) {
                            return e.key - t.key
                        }))
    },
    countDownChanged(e) { 
      this.dismissCountDown = e
    },
    showAlert(mensaje,tipoA) {
      this.mensaje = mensaje, this.tipoAlerta = tipoA, this.mostrarMensaje = true, this.dismissCountDown = this.dismissSecs
    },
    ObtenerTipocambio() {
        var e = this;
        this.$refs["modal-tipoCambio"].show(); 
        this.$services.ajusteAnualService.ObtenerCatalogoTipoCambioporEjercicio(this.ejercicio).then((function (t) {
                            t.data.key && 
                              (e.tiposCambio.splice(0), 
                              t.data.key.forEach((function (t) 
                                {
                                t.mes = e.MesesCambio[t.periodo - 1], e.tiposCambio.push(t)
                                }
                                )))
                        })).catch((function (t) {
                            500 === t.response.status && e.showAlert(t.response.data.value, "danger")
                        }));
    },
    ObtenerRangoMeses(e,t) {

        var o = this;
                this.$services.ajusteAnualService.ObtenerRangoMeses(e, t).then((function (e) {
                    "" === e.data.value && (o.Meses = o.Meses.slice(e.data.key.periodoInicio - 1, e.data.key.periodoFin))
                })).catch((function (e) {
                    console.log(e)
                }))
    },
    ObtenerTotalPeriodosDeudasCreditos(e, t, o) {
        var a = this;
        this.$services.ajusteAnualService.ObtenerTotalPeriodosDeudasCreditos(e, t, o).then((function (e) {
            "" === e.data.value && (a.totales = e.data.key.totalCuentaPeriodo, a.totales.forEach((function (e) {
                e.totalPeriodo = a.sortedArray(e.totalPeriodos)
            })), a.CalcularActualizarTotalesPorMes())
        })).catch((function (e) {
            console.log(e)
        }))
    },
    CalcularActualizarTotalesPorMes(e) {
        var t = this;
        this.totalFinalCuenta = 0, this.sumaTotales = 0, this.totales.forEach((function (e) {
            if (e.activo) {
                var o = 0;
                e.totalPeriodos.forEach((function (e) {
                    o += e.value
                })), e.totalFinalCuenta = o, t.sumaTotales = t.sumaTotales + e.totalFinalCuenta
            } else e.totalFinalCuenta = 0
        })), "undefined" !== typeof e && null !== e && this.ActualizarTotales(e)

    },
    ActualizarTotales(e) {

      var t = this;
      this.$services.ajusteAnualService.ActualizarTotalPeriodoCreditosDeudas(e, this.empresaId, this.ejercicio, this.tipoReporte, this.sumaTotales).then((function (o) {
          "" != o.data.value ? t.showAlert(o.data.value, "danger") : e.activo && t.ObtenerTotalPeriodosDeudasCreditos(t.empresaId, t.ejercicio, t.tipoReporte)
      })).catch((function (e) {
          console.log(e)
      }))

    },
  },
  mounted() {
    this.ObtenerRangoMeses(this.empresaId, this.ejercicio), this.ObtenerTotalPeriodosDeudasCreditos(this.empresaId, this.ejercicio, this.tipoReporte)
  },
};

</script>
<style>
thead th {
    background-color: #2c3e50;
    color: #fff
}

td.details-control {
    background: url(https://datatables.net/examples/resources/details_open.png) no-repeat 50%;
    cursor: pointer
}

tr.shown td.details-control {
    background: url(https://datatables.net/examples/resources/details_close.png) no-repeat 50%
}

tfoot tr {
    background-color: #2c3e50;
    color: #fff
}
.tippy-tooltip.basal-theme {
    background: #bfad4d
}

.router-link-exact-active,
.router-link-exact-active:hover {
    cursor: pointer;
    text-decoration: none;
    color: #fff;
    font-weight: 700
}

.footerEstatico>thead>tr>th {
    position: sticky;
    position: -webkit-sticky;
    top: 0;
    z-index: 2
}

td,
th {
    white-space: nowrap
}

table {
    border-collapse: separate !important;
    font-size: .8em
}

thead {
    display: table-header-group
}

tbody,
thead {
    vertical-align: middle;
    border-color: inherit
}

tbody {
    display: table-row-group
}

foot {
    display: table-footer-group;
    border-color: inherit
}

foot,
table>tr {
    vertical-align: middle
}

col {
    display: table-column
}

colgroup {
    display: table-column-group
}

tr {
    display: table-row;
    border-color: inherit
}

td,
th,
tr {
    vertical-align: inherit
}

td,
th {
    display: table-cell
}

th {
    font-weight: 700
}

caption {
    display: table-caption;
    text-align: -webkit-center
}

.headerEstatico>thead>tr>th {
    position: sticky;
    position: -webkit-sticky;
    top: 0;
    z-index: 2
}

.inputCheck {
    margin-left: 25%
}

.linkDetalleCuenta:hover {
color:white !important;
text-decoration:none !important;
}
.linkDetalleCuenta {
color:white !important;
text-decoration:none !important;
}
</style>