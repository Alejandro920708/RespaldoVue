<template>
  <div>
    <div class="container">
      <div class="row">
        <div class="col-md-12 mb-2 mt-5">
          <router-link :to="{ name: 'DetallePoliza' }">
            <i class="fas fa-arrow-alt-circle-left fa-2x"></i>
          </router-link>
        </div>
        <div class="col-md-12 list-group mb-5 mt-1" id="infinite-list">
          <div class="text-center dvLoading" v-show="loading">
            <div class="spinner-border" role="status">
              <span class="sr-only">Loading...</span>
            </div>
          </div>
          <b-table striped hover :items="transacciones" :fields="fields">
          </b-table>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "DetalleTransaccion",
  props: {},
  components: {},
  data() {
    return {
      loading: false,
      items: [],
      omite: 0,
      toma: 0,
      periodo: 0,
      empresaId: 0,
      ejercicio: 0,
      transacciones: [],
      fields: [
        {
          key: "numCta",
          label: "Número de cuenta",
        },
        {
          key: "desCta",
          label: "Descripción Cuenta",
        },
        {
          key: "concepto",
          label: "Concepto",
        },
        {
          key: "debe",
          label: "Debe",
        },
        {
          key: "haber",
          label: "Haber",
        }
      ],
    };
  },
  methods: {
    loadMore() {
      this.loading = true;
      this.$services.polizaService
        .ObtenerPaginacionTransacciones(
          this.polizaId,
          this.empresaId,
          this.ejercicio,
          this.periodo,
          this.omite,
          this.toma
        )
        .then((r) => {
          console.log(r);
          r.data.key.forEach((t) => {
            console.log(t);
            this.transacciones.push(t);
          });
          this.loading = false;
        })
        .catch((r) => {
          console.log(r);
          this.loading = false;
        });
    },
  },
  mounted() {
    this.omite = 0;
    this.toma = 10;
    if (this.$route.params.periodo) {
      this.polizaId=this.$route.params.polizaId;
      this.periodo = this.$route.params.periodo;
      this.empresaId = this.$route.params.empresaId;
      this.ejercicio = this.$route.params.ejercicio;
    }

    const listElm = document.querySelector("#infinite-list");
    listElm.addEventListener("scroll", () => {
      if (listElm.scrollTop + listElm.clientHeight >= listElm.scrollHeight) {
        this.omite = this.omite + this.toma;
        this.toma = 10;
        this.loadMore();
      }
    });

    this.loadMore();
  },
};
</script>

<style>
.list-group {
  overflow: auto;
  height: 75vh;
  border: 0px solid;
  border-radius: 5px;
}

.dvLoading {
  padding: 20px;
  border-radius: 10px;
  height: 150px;
  width: 250px;
  position: fixed;
  z-index: 1000;
  left: 50%;
  top: 50%;
  margin: -125px 0 0 -125px;
  text-align: center;
}
</style>