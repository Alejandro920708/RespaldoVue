<template>
  <div>
    <div>
      <p v-for="item in list" :key="item">
        Line:
        <span v-text="item"></span>
      </p>
      <infinite-loading @infinite="infiniteHandler"></infinite-loading>
    </div>
  </div>
</template>

<script>
import InfiniteLoading from "vue-infinite-loading";

export default {
  name: "InfiniteScroll",
  props: {},
  components: {
    InfiniteLoading
  },
  data() {
    return {
        list: [],
    };
  },
  methods: {
    infiniteHandler($state) {
        console.log($state)
      setTimeout(() => {
        const temp = [];
        for (let i = this.list.length + 1; i <= this.list.length + 20; i++) {
          temp.push(i);
        }
        this.list = this.list.concat(temp);
        $state.loaded();
      }, 1000);
    },
  },
  mounted() {},
};
</script>