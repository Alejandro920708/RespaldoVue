<template>
  <div>
    <div class="row">
      <div class="col-md-12">
        <table class="table table-bordered mt-5">
          <tr>
            <td>Nivel</td>
            <td>NumeroCuenta</td>
            <td>Subcuentade</td>
            <td>Total</td>
            <td>Activar/Desactivar</td>
            <td>Captura</td>
            <td>TotalFinal</td>
            <td>Tienesubcuentas</td>
          </tr>
          <tr v-for="cuenta in cuentas" :key="cuenta.Id">
            <td>{{ cuenta.Nivel }}</td>
            <td>{{ cuenta.NumeroCuenta }}</td>
            <td>{{ cuenta.Subcuentade }}</td>
            <td>{{ cuenta.Total }}</td>
            <td>
              <input
                type="checkbox"
                v-model="cuenta.Activar"
                @change="check(cuenta)"
              />
            </td>
            <td>
              <input type="text" v-model="cuenta.Captura" />
            </td>
            <td>{{ cuenta.TotalFinal }}</td>
            <td>{{ cuenta.TieneSubcuentas }}</td>
          </tr>
        </table>
      </div>
    </div>
  </div>
</template>

<script>

import Enumerable from "linq";

export default {
  name: "SumaTabla",
  props: {},
  components: {},
  data() {
    return {
      cuentas: [
        {
          Nivel: 2,
          NumeroCuenta: "0001-001",
          Total: 20,
          Activar: true,
          Captura: 0,
          TotalFinal: 20,
          Subcuentade: null,
          TieneSubcuentas: 1,
          Id: 1,
        },
        {
          Nivel: 3,
          NumeroCuenta: "0001-001-001",
          Total: 10,
          Activar: true,
          Captura: 0,
          TotalFinal: 10,
          Subcuentade: "0001-001",
          TieneSubcuentas: 1,
          Id: 2,
        },
        {
          Nivel: 4,
          NumeroCuenta: "0001-001-001-001",
          Total: 5,
          Activar: true,
          Captura: 0,
          TotalFinal: 5,
          Subcuentade: "0001-001-001",
          TieneSubcuentas: 0,
          Id: 3,
        },
        {
          Nivel: 4,
          NumeroCuenta: "0001-001-001-002",
          Total: 5,
          Activar: true,
          Captura: 0,
          TotalFinal: 5,
          Subcuentade: "0001-001-001",
          TieneSubcuentas: 0,
          Id: 4,
        },
        {
          Nivel: 3,
          NumeroCuenta: "0001-001-002",
          Total: 10,
          Activar: true,
          Captura: 0,
          TotalFinal: 10,
          Subcuentade: "0001-001",
          TieneSubcuentas: 1,
          Id: 5,
        },
        {
          Nivel: 4,
          NumeroCuenta: "0001-001-001-003",
          Total: 5,
          Activar: true,
          Captura: 0,
          TotalFinal: 5,
          Subcuentade: "0001-001-002",
          TieneSubcuentas: 0,
          Id: 6,
        },
        {
          Nivel: 4,
          NumeroCuenta: "0001-001-001-004",
          Total: 5,
          Activar: true,
          Captura: 0,
          TotalFinal: 5,
          Subcuentade: "0001-001-002",
          TieneSubcuentas: 0,
          Id: 7,
        },
        /*{
          Nivel: 2,
          NumeroCuenta: "0001-002",
          Total: 20,
          Activar: true,
          Captura: 0,
          TotalFinal: 20,
          Subcuentade: null,
          TieneSubcuentas: 1,
          Id: 8,
        },
        {
          Nivel: 3,
          NumeroCuenta: "0001-001-003",
          Total: 10,
          Activar: true,
          Captura: 0,
          TotalFinal: 10,
          Subcuentade: "0001-002",
          TieneSubcuentas: 1,
          Id: 9,
        },
        {
          Nivel: 4,
          NumeroCuenta: "0001-001-001-005",
          Total: 5,
          Activar: true,
          Captura: 0,
          TotalFinal: 5,
          Subcuentade: "0001-001-003",
          TieneSubcuentas: 0,
          Id: 10,
        },
        {
          Nivel: 4,
          NumeroCuenta: "0001-001-001-006",
          Total: 5,
          Activar: true,
          Captura: 0,
          TotalFinal: 5,
          Subcuentade: "0001-001-003",
          TieneSubcuentas: 0,
          Id: 11,
        },
        {
          Nivel: 3,
          NumeroCuenta: "0001-001-004",
          Total: 10,
          Activar: true,
          Captura: 0,
          TotalFinal: 10,
          Subcuentade: "0001-002",
          TieneSubcuentas: 1,
          Id: 12,
        },
        {
          Nivel: 4,
          NumeroCuenta: "0001-001-001-007",
          Total: 5,
          Activar: true,
          Captura: 0,
          TotalFinal: 5,
          Subcuentade: "0001-001-004",
          TieneSubcuentas: 0,
          Id: 13,
        },
        {
          Nivel: 4,
          NumeroCuenta: "0001-001-001-008",
          Total: 5,
          Activar: true,
          Captura: 0,
          TotalFinal: 5,
          Subcuentade: "0001-001-004",
          TieneSubcuentas: 0,
          Id: 14,
        },*/
      ],
    };
  },
  methods: {
    check(cuenta) {

        if(cuenta.Nivel ==2) {
            if(cuenta.TieneSubcuentas > 0){
                let arregloCuentasNivel3 = [];
                for (let i = 0; i < this.cuentas.length; i++) {
                    if((this.cuentas[i].Subcuentade == cuenta.NumeroCuenta) && (this.cuentas[i].Nivel == 3)){
                            if(cuenta.Activar){
                                this.cuentas[i].Activar = true;
                                this.cuentas[i].TotalFinal = this.cuentas[i].Total;
                            }else{
                                this.cuentas[i].Activar = false;
                                this.cuentas[i].TotalFinal = 0;
                            }
                            arregloCuentasNivel3.push(this.cuentas[i])
                    }  
                }
                
                for (let i = 0; i < arregloCuentasNivel3.length; i++) {
                    if(arregloCuentasNivel3[i].TieneSubcuentas >0){
                        for (let x = 0; x < this.cuentas.length; x++) {
                            if(this.cuentas[x].Subcuentade == arregloCuentasNivel3[i].NumeroCuenta){
                                if(cuenta.Activar){
                                    this.cuentas[x].Activar = true;
                                    this.cuentas[x].TotalFinal = this.cuentas[x].Total;
                                }else{
                                    this.cuentas[x].Activar = false;
                                    this.cuentas[x].TotalFinal = 0;
                                }
                            }
                        }
                    }
                }
                this.SumaNivel2(cuenta);
            }
        } else if(cuenta.Nivel == 3){ 
            if(cuenta.TieneSubcuentas > 0){
                for (let i = 0; i < this.cuentas.length; i++) {
                    if(this.cuentas[i].Subcuentade == cuenta.NumeroCuenta){
                            if(cuenta.Activar){
                            this.cuentas[i].Activar = true;
                            this.cuentas[i].TotalFinal = this.cuentas[i].Total;
                        }else{
                            this.cuentas[i].Activar = false;
                            this.cuentas[i].TotalFinal = 0;
                        }
                    }
                }
                this.SumaNivel3(cuenta);
            }
        }
        else if(cuenta.Nivel ==4){
          if(cuenta.Activar){
            cuenta.TotalFinal = cuenta.Total;
          }else{
            cuenta.TotalFinal = 0;
          }
          this.SumaNivel4(cuenta);
        }

    },
    SumaNivel2(cuenta) {
        let arregloCuentasNivel3 = [];
        let sumaCuentasNivel3=0;
        
        for (let i = 0; i < this.cuentas.length; i++) {
            if ((this.cuentas[i].Subcuentade == cuenta.NumeroCuenta) && (this.cuentas[i].Activar)) {
                arregloCuentasNivel3.push(this.cuentas[i]);
            }
        }

        for (let i = 0; i < arregloCuentasNivel3.length; i++) {
            sumaCuentasNivel3 += arregloCuentasNivel3[i].TotalFinal;
        }

        Enumerable.from(this.cuentas).where(function(x){
            if(x.NumeroCuenta== cuenta.NumeroCuenta)
              return x.NumeroCuenta
           }).first().TotalFinal = sumaCuentasNivel3;


        /*console.log(Enumerable.from(this.cuentas).where(function(x){
            if(x.Subcuentade== "0001-001")
              return x.NumeroCuenta
           }).toArray())*/
           
    }, 
    SumaNivel3(cuenta){
      
        let arregloCuentasNivel4 = [];
        let sumaCuentasNivel4=0;

        for (let i = 0; i < this.cuentas.length; i++) {
            if ((this.cuentas[i].Subcuentade == cuenta.NumeroCuenta) && (this.cuentas[i].Activar)) {
                arregloCuentasNivel4.push(this.cuentas[i]);
            }
        }
        
        for (let i = 0; i < arregloCuentasNivel4.length; i++) {
            sumaCuentasNivel4 += arregloCuentasNivel4[i].TotalFinal;
        }

        Enumerable.from(this.cuentas).where(function(x){
            if(x.NumeroCuenta== cuenta.NumeroCuenta)
              return x.NumeroCuenta
           }).first().TotalFinal = sumaCuentasNivel4;

        let sumaCuentasNivel3=0;
        Enumerable.from(this.cuentas).forEach(function(value){
          if((value.Subcuentade ==cuenta.Subcuentade) && (value.Activar)){
            sumaCuentasNivel3 += value.TotalFinal;
          }
        });

        Enumerable.from(this.cuentas).where(function(x){
            if(x.NumeroCuenta== cuenta.Subcuentade)
              return x.NumeroCuenta
           }).first().TotalFinal = sumaCuentasNivel3;

    },
    SumaNivel4(cuenta){
      
      let sumaCuentasNivel4 = 0;
      Enumerable.from(this.cuentas).forEach(function(value){
        if((value.Subcuentade ==cuenta.Subcuentade) && (value.Activar)){
          sumaCuentasNivel4 += value.TotalFinal;
        }
      });

      Enumerable.from(this.cuentas).where(function(x){
            if(x.NumeroCuenta== cuenta.Subcuentade)
              return x.NumeroCuenta
           }).first().TotalFinal=sumaCuentasNivel4;

      let cuentaNivel3 = Enumerable.from(this.cuentas).where(function(x){
            if(x.NumeroCuenta== cuenta.Subcuentade)
              return x.NumeroCuenta
           }).first();

      console.log(cuentaNivel3)

      let sumaCuentasNivel3=0;
        Enumerable.from(this.cuentas).forEach(function(value){
        if((value.Subcuentade ==cuentaNivel3.Subcuentade) && (value.Activar)){
          sumaCuentasNivel3 += value.TotalFinal;
        }
      });
      console.log(sumaCuentasNivel3)

      Enumerable.from(this.cuentas).where(function(x){
            if(x.NumeroCuenta== cuentaNivel3.Subcuentade)
              return x.NumeroCuenta
           }).first().TotalFinal = sumaCuentasNivel3;


    }
  },
  mounted() {
  },
};
</script>