<template>
  <div>
    <b-container>
      <h3>Pólizas</h3>
      <hr color="#10102b" />
      <button class="btn btn-primary" v-on:click="MostrarTipoReporte()">
        mostrar tipo de reporte
      </button>
      <poliza
        v-show="mostrarPoliza"
        :empresaId="empresaId"
        :ejercicio="ejercicio"
        ref="periodosPolizas"
        v-bind:tipoReporte="tipoReporte"
        v-bind:periodoInicio="periodoInicio"
        v-bind:periodoFin="periodoFin"
        v-bind:accion="accion"
        v-bind:periodo="periodo"
      ></poliza>
    </b-container>
    <b-modal
      ref="my-modal"
      hide-footer
      title="Using Component Methods"
      no-close-on-backdrop
    >
      <div class="d-block text-center">
        <h3>Hello From My Modal!</h3>
      </div>
      <form @submit.prevent="GuardarTipoReporte">
        <b-row>
          <input v-model="modelo.rangoId" type="hidden" />

          <b-col cols="12">
            <div class="form-group">
              <label for="tipo">Tipo de reporte</label>
              <b-form-select
                v-model="modelo.tipo"
                @change="SeleccionarPeriodos"
                :options="tiposReporte"
                :class="{ 'is-invalid': submitted && $v.modelo.tipo.$error }"
              ></b-form-select>
              <div
                v-if="submitted && !$v.modelo.tipo.required"
                class="invalid-feedback"
              >
                Tipo es requerido
              </div>
            </div>
          </b-col>

          <b-col cols="12">
            <div class="form-group">
              <label for="tipo">Periodo de inicio</label>
              <b-form-select
                v-model="modelo.periodoInicio"
                :options="periodos"
                :class="{
                  'is-invalid': submitted && $v.modelo.periodoInicio.$error,
                }"
                v-if="desactivaSelect"
                disabled
              ></b-form-select>
              <b-form-select
                v-model="modelo.periodoInicio"
                :options="periodos"
                :class="{
                  'is-invalid': submitted && $v.modelo.periodoInicio.$error,
                }"
                v-else
              ></b-form-select>
              <div
                v-if="submitted && !$v.modelo.periodoInicio.required"
                class="invalid-feedback"
              >
                Periodo de inicio es requerido
              </div>
            </div>
          </b-col>

          <b-col cols="12">
            <div class="form-group">
              <label for="tipo">Periodo de fin</label>
              <b-form-select
                v-model="modelo.periodoFin"
                :options="periodos"
                :class="{
                  'is-invalid': submitted && $v.modelo.periodoFin.$error,
                }"
                v-if="desactivaSelect"
                disabled
              ></b-form-select>
              <b-form-select
                v-model="modelo.periodoFin"
                :options="periodos"
                :class="{
                  'is-invalid': submitted && $v.modelo.periodoFin.$error,
                }"
                v-else
              ></b-form-select>
              <div
                v-if="submitted && !$v.modelo.periodoFin.required"
                class="invalid-feedback"
              >
                Periodo de fin es requerido
              </div>
            </div>
          </b-col>

          <b-col cols="1">
            <button type="submit" class="btn btn-primary">Guardar</button>
          </b-col>
        </b-row>
      </form>
    </b-modal>
  </div>
</template>

<script>
import Poliza from "./Poliza.vue";
import { required } from "vuelidate/lib/validators";

export default {
  name: "TipoReporte",
  props: {
    empresaId: Number,
    ejercicio: Number,
  },
  components: {
    Poliza,
  },
  data() {
    return {
      submitted: false,
      tiposReporte: [],
      periodos: [],
      modelo: {
        rangoId: 0,
        tipo: null,
        periodoInicio: null,
        periodoFin: null,
        idEmpresa: 0,
        ejericicio: 0,
      },
      mostrarPoliza: false,
      desactivaSelect: false,
      tipoReporte: "",
      periodoInicio: 0,
      periodoFin: 0,
      accion: 0,
      periodo: false,
    };
  },
  validations: {
    modelo: {
      rangoId: { required },
      tipo: { required },
      periodoInicio: { required },
      periodoFin: { required },
    },
  },
  methods: {
    ObtenerTipoReporte(modal) {
      this.$services.demService
        .ObtenerTipoReporte(this.empresaId, this.ejercicio)
        .then((r) => {
          this.$refs.periodosPolizas.ObtenerPeriodos(
            r.data.key.tipo,
            r.data.key.periodoInicio,
            r.data.key.periodoFin,
            2,
            false
          );

          if (modal) {
            this.modelo.rangoId = r.data.key.idRango;
            this.modelo.tipo = r.data.key.tipo;
            this.modelo.periodoInicio = r.data.key.periodoInicio;
            this.modelo.periodoFin = r.data.key.periodoFin;

            this.$refs["my-modal"].show();

            let servicioPeriodos = {};

            if (r.data.key.tipo === "PROVISIONAL") {
              servicioPeriodos = this.$services.polizaService.ObtenerPeriodos(
                r.data.key.tipo,
                r.data.key.periodoInicio,
                r.data.key.periodoFin,
                2,
                false
              );
            } else {
              servicioPeriodos = this.$services.polizaService.ObtenerPeriodos(
                r.data.key.tipo,
                0,
                0,
                2,
                false
              );
            }

            const servicioTiposReporte = this.$services.polizaService.ObtenerTiposReporte();

            this.periodos = [];
            this.tiposReporte = [];
            Promise.all([servicioPeriodos, servicioTiposReporte]).then(
              (listaRespuestas) => {
                this.periodos.push({
                  value: null,
                  text: "Seleciona una opción",
                });
                listaRespuestas[0].data.forEach((periodo) =>
                  this.periodos.push({
                    value: periodo.key,
                    text: periodo.value,
                  })
                );

                this.tiposReporte.push({
                  value: null,
                  text: "Seleciona una opción",
                });
                listaRespuestas[1].data.forEach((tipo) =>
                  this.tiposReporte.push({
                    value: tipo.key,
                    text: tipo.value,
                  })
                );
              }
            );
          } else {
            this.$refs["my-modal"].hide();
            this.mostrarPoliza = true;
            const servicioPeriodos = this.$services.polizaService.ObtenerPeriodos(
              r.data.key.tipo,
              0,
              0,
              2,
              false
            );

            const servicioTiposReporte = this.$services.polizaService.ObtenerTiposReporte();

            this.periodos = [];
            this.tiposReporte = [];
            Promise.all([servicioPeriodos, servicioTiposReporte]).then(
              (listaRespuestas) => {
                this.periodos.push({
                  value: null,
                  text: "Seleciona una opción",
                });
                listaRespuestas[0].data.forEach((periodo) =>
                  this.periodos.push({
                    value: periodo.key,
                    text: periodo.value,
                  })
                );

                this.tiposReporte.push({
                  value: null,
                  text: "Seleciona una opción",
                });
                listaRespuestas[1].data.forEach((tipo) =>
                  this.tiposReporte.push({
                    value: tipo.key,
                    text: tipo.value,
                  })
                );
              }
            );
          }
        })
        .catch((r) => {
          if (r.response.status === 404) {
            if (r.response.data.key.idRango === 0) {
              this.$refs["my-modal"].show();

              const servicioPeriodos = this.$services.polizaService.ObtenerPeriodos(
                r.response.data.key.tipo,
                0,
                0,
                2,
                false
              );

              const servicioTiposReporte = this.$services.polizaService.ObtenerTiposReporte();

              this.periodos = [];
              this.tiposReporte = [];
              Promise.all([servicioPeriodos, servicioTiposReporte]).then(
                (listaRespuestas) => {
                  this.periodos.push({
                    value: null,
                    text: "Seleciona una opción",
                  });
                  listaRespuestas[0].data.forEach((periodo) =>
                    this.periodos.push({
                      value: periodo.key,
                      text: periodo.value,
                    })
                  );

                  this.tiposReporte.push({
                    value: null,
                    text: "Seleciona una opción",
                  });
                  listaRespuestas[1].data.forEach((tipo) =>
                    this.tiposReporte.push({
                      value: tipo.key,
                      text: tipo.value,
                    })
                  );
                }
              );
            }
          }
        });
    },
    GuardarTipoReporte() {
      this.submitted = true;
      this.$v.$touch();
      if (this.$v.$invalid) {
        return;
      } else {
        this.modelo.idEmpresa = this.empresaId;
        this.modelo.ejercicio = this.ejercicio;
        this.$services.demService
          .GuardarTipoReporte(this.modelo)
          .then((r) => {
            console.log(r.data);
            this.ObtenerTipoReporte();
          })
          .catch((r) => {
            console.log(r);
          });
      }
    },
    SeleccionarPeriodos() {
      if (this.modelo.tipo) {
        if (this.modelo.tipo === "NORMAL") {
          this.modelo.periodoInicio = 1;
          this.modelo.periodoFin = 12;
          this.desactivaSelect = true;
          this.periodos = [];
          this.$services.polizaService
            .ObtenerPeriodos(this.modelo.tipo, 0, 0, 2, false)
            .then((resultado) => {
              this.periodos.push({
                value: null,
                text: "Seleciona una opción",
              });
              resultado.data.forEach((periodo) =>
                this.periodos.push({
                  value: periodo.key,
                  text: periodo.value,
                })
              );
            })
            .catch((resultado) => {
              console.log(resultado);
            });
        } else {
          // Provisional
          this.modelo.periodoInicio = null;
          this.modelo.periodoFin = null;
          this.desactivaSelect = false;
          this.periodos = [];
          this.$services.polizaService
            .ObtenerPeriodos(this.modelo.tipo, 0, 0, 1, false)
            .then((resultado) => {
              this.periodos.push({
                value: null,
                text: "Seleciona una opción",
              });
              resultado.data.forEach((periodo) =>
                this.periodos.push({
                  value: periodo.key,
                  text: periodo.value,
                })
              );
            })
            .catch((resultado) => {
              console.log(resultado);
            });
        }
      } else {
        if (this.desactivaSelect) {
          this.desactivaSelect = false;
        }
        this.modelo.periodoInicio = null;
        this.modelo.periodoFin = null;
        this.periodos = [];
        this.$services.polizaService
          .ObtenerPeriodos(this.modelo.tipo, 0, 0, 2, false)
          .then((resultado) => {
            this.periodos.push({
              value: null,
              text: "Seleciona una opción",
            });
            resultado.data.forEach((periodo) =>
              this.periodos.push({
                value: periodo.key,
                text: periodo.value,
              })
            );
          })
          .catch((resultado) => {
            console.log(resultado);
          });
      }
    },
    MostrarTipoReporte() {
      this.ObtenerTipoReporte(true);
    },
  },
  mounted() {
    this.ObtenerTipoReporte();
  },
};
</script>