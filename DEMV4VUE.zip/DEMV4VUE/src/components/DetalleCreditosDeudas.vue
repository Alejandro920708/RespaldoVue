<template>
    <div class="container">
        <b-row>
             <b-col cols="1">
                <div style="height: 50px; margin-top: 10px;">  
                    <router-link 
                        :to="{name:'CreditosDeudas'}"
                        >
                        <i class="fas fa-arrow-alt-circle-left fa-2x">
                        </i>
                        </router-link>
                    </div>
            </b-col>
         
        </b-row>
        <b-row>
               <b-col cols="6" offset="2">
            
                <b-alert
                :variant="tipoAlerta"
                dismissible=""
                fade=""
                :show="mostrarMensaje"
                @dismissed="mostrarMensaje=false"
                >
                <p class="text-center">{{mensaje}}</p>
                </b-alert>
            </b-col>
            <b-col cols="4" offset="8">
                    <div style="margin-top:10%;margin-bottom:10%"> 
                        <b-button 
                            variant="primary" pill=""
                            @click="GuardarCambios()" > 
                            Guardar Cambios
                        </b-button> 
                    </div>
            </b-col>
      </b-row>
      <!-- Inicio b-row tabla-->
       <b-row>
            <b-col cols="12">
            <div  style="height:88vh; overflow: auto;">
                <table class="table table-bordered headerEstatico">
              <thead>
               <tr>
                 <th scope="col" class="text-center">Cuenta</th>
                 <th scope="col" class="text-center">Subcuenta de</th>
                 <th scope="col" class="text-center">Concepto</th>
                 <th scope="col" class="text-center">Total Balanza</th>
                 <th scope="col" class="text-center">Activo</th>
                 <th scope="col" class="text-center" v-if="mostrarEvaluar">Valuar</th>
                 <th scope="col" class="text-center">Nivel</th>
                 <th scope="col" class="text-center">Capturar</th>
                 <th scope="col" class="text-center">Total Final</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="saldo in saldos" :key="saldo.id">
                    <td>{{saldo.numeroCuenta}}</td>
                    <td>{{saldo.subCuentaDe}}</td>
                    <td>{{saldo.descripcion}}</td>
                    <td>{{saldo.totalBalanza|currencidecimal}}</td>
                    <td class="centered" v-if="!saldo.estatusCaptura">
                        <input type="checkbox" class="inputCheck" v-model="saldo.activo" @change="cambiarEstatusActivo(saldo.activo,saldo)">
                    </td>
                    <td class="centered" v-else>
                        <input type="checkbox" class="inputCheck" disabled="disabled" v-model="saldo.activo" >
                    </td>
                    <td class="centered" v-if="mostrarEvaluar">
                        <div v-if="(saldo.activo && !saldo.estatusCaptura) && saldo.nivel!=2">
                                <input type="checkbox" class="inputCheck" v-model="saldo.valuar" @change="cambiarTotalValuado(saldo.valuar,saldo)">
                        </div>
                        <div v-else-if="(!saldo.activo || saldo.estatusCaptura) && saldo.nivel!=2">
                                <input type="checkbox" class="inputCheck" disabled v-model="saldo.valuar">
                        </div>
                    </td>
                    <td class="centered">
                        {{saldo.nivel}}
                   </td>
                   <td>
                       <div v-if="((saldo.activo && !saldo.valuar && !saldo.estatusCaptura) || saldo.totalCaptura !=0) && ( 2 != saldo.nivel && tieneHijos)">
                        <input type="input" min=0 style="width:100px;" v-model="saldo.totalCaptura" @change="calcularCapturado(saldo)">
                        </div>
                        <div v-else-if="( 2 != saldo.nivel && tieneHijos)">
                            <input type="input" style="width:100px;" disabled=disabled v-model="saldo.totalCaptura">
                        </div>
                       <!-- <div v-if="(((saldo.activo && !saldo.valuar) &&( !saldo.estatusCaptura || saldo.totalCaptura >=0)) && ( 2 != saldo.nivel && tieneHijos))">
                        <input type="input" style="width:100px;" v-model="saldo.totalCaptura" @change="calcularCapturado(saldo)">
                        </div>
                        <div v-else-if="(((!saldo.activo || saldo.valuar) || (saldo.estatusCaptura || saldo.totalCaptura <0)) && ( 2 != saldo.nivel && tieneHijos))">
                            <input type="input" style="width:100px;" disabled=disabled v-model="saldo.totalCaptura">
                        </div> -->
                   </td>
                   <td v-if="saldo.activo">
                        {{saldo.totalFinal|currencidecimal}}
                   </td>
                   <td v-else>
                        {{0|currencidecimal}}
                   </td>
                </tr>
              </tbody>
              <tfoot class="footerEstatico">
                <tr>
                </tr>
              </tfoot>
          </table>
            </div>
            </b-col>
            
      </b-row>
    </div>
</template>
<script>

export default {
  name: "DetalleCreditosDeudas",
  props: {
        empresaId: Number,
        ejercicio: Number
  },
  components: {},
  data() {
       return {
            mostrarEvaluar: false,
            loading: false,
            omite: 0,
            toma: 0,
            saldos: [],
            tipoCambio: 0,
            mensaje: "",
            mostrarMensaje: false,
            dismissSecs: 15,
            dismissCountDown: 0,
            tipoAlerta: "",
            numeroCuentaPadre: String,
            periodo: Number,
            estatusPadre: false,
            tieneHijos: false
        }
  
  },
  filters:{
    currencidecimal(e, t, o){
      var a = /(\d{3})(?=\d)/g;
      if (e = parseFloat(e), !isFinite(e) || !e && 0 !== e) return "";
      t = null != t ? t : "$", o = null != o ? o : 2;
      var i = Math.abs(e).toFixed(o),
          r = o ? i.slice(0, -1 - o) : i,
          s = r.length % 3,
          n = s > 0 ? r.slice(0, s) + (r.length > 3 ? "," : "") : "",
          c = o ? i.slice(-1 - o) : "",
          l = e < 0 ? "-" : "";
      return l + t + n + r.slice(s).replace(a, "$1,") + c
    }
  },
  methods: {
   ObtenerParametrosAjusteAnual(){
       var e = this;
        this.$services.ajusteAnualService.ObtenerParametrosAjusteAnual(this.empresaId, this.ejercicio, 21).then((function (t) {
                t.data.key && t.data.key.forEach((function (t) {
                    28 == t.preguntaId && (e.mostrarEvaluar = t.respuesta)
                }))
        })).catch((function (t) {
                500 === t.response.status && e.showAlert(t.response.data.value, "danger")
            }))
   },
   ObtenerTipocambio(){
       var e = this;
            this.$services.ajusteAnualService.ObtenerCatalogoTipoCambioporEjercicio(this.ejercicio).then((function (t) {
                t.data.key && t.data.key.forEach((function (t) {
                    t.periodo == e.periodo && (e.tipoCambio = t.tipoCambio)
                }))
            })).catch((function (t) {
                500 === t.response.status && e.showAlert(t.response.data.value, "danger")
            }))
   },
calcularCapturado(e) {
    this.verificarNegativos(e)
       if (e.nivel > 2 && e.nivel <= 4) {
                e.estatusCaptura =  e.totalCaptura > 0;
                var t = this.filtroSubCuentas(e.numeroCuenta);  
                t.forEach((function (t) {
                    t.totalCaptura = 0, e.estatusCaptura ? (t.totalFinal = 0, t.estatusCaptura = e.estatusCaptura) : (t.totalFinal = t.totalBalanza, t.estatusCaptura = e.estatusCaptura), true
                })), e.estatusCaptura ? e.totalFinal = e.totalCaptura : e.totalFinal = e.totalBalanza;
                var o = this.filtroCuentasHermano(e.subCuentaDe),
                    a = 0,
                    i = 0;
                o.forEach((function (e) {
                    i += parseFloat(e.totalFinal), 1, e.estatusCaptura && (a += 1)
                }));
                var r = this.filtroCuentaPadre(e.subCuentaDe);
                r.forEach((function (e) {
                    e.totalFinal = i, e.nivel > 2 && (e.estatusCaptura = true), 0 == a && (e.estatusCaptura = false)
                }))
            }
            2 != e.nivel || this.tieneHijos || (e.estatusCaptura = e.totalCaptura > 0, e.estatusCaptura ? e.totalFinal = parseFloat(e.totalCaptura) : e.totalFinal = e.totalBalanza)
   },
   verificarNegativos(captura){
           captura.totalCaptura = captura.totalCaptura.replace(/[^\d*[0-9]\.\d*[0-9]]+/g, ''); // Clear characters other than "number" and "."

        // if (captura.totalCaptura.indexOf('.') < 0 && captura.totalCapturaa != '') {
            if (captura.totalCapturaa != '') {
                    // The above has been filtered. The control here is that if there is no decimal point, the first digit cannot be an amount similar to 01, 02.
             captura.totalCaptura = parseFloat(captura.totalCaptura);
              
                if(captura.totalCaptura<0)
                {
                    captura.totalCaptura =Math.abs(captura.totalCaptura);
                }
                const calcDec = Math.pow(10, 2);
                    captura.totalCaptura = Math.trunc(captura.totalCaptura * calcDec) / calcDec;
                    // console.log(captura.totalCaptura)

            if(isNaN(captura.totalCaptura))
            {
                captura.totalCaptura=0;
            }
        }
    },
   cambiarEstatusActivo(e, t) {
       this.calcularTotalesRecursivoDescendiente(e, t), this.calcularTotalesRecursivoAscendiente(e, t)
   },
   calcularTotalesRecursivoDescendiente(e, t) {
       var o = this,
                a = 0,
                i = this.filtroSubCuentas(t.numeroCuenta);
            return i.length > 0 ? i.forEach((function (t) {
                t.activo = e, t.valuar = false, a += o.calcularTotalesRecursivoDescendiente(e, t)
            })) : a = e ? t.totalBalanza : t.totalFinal, t.valuar = false, t.totalFinal = a, a
   },
   calcularTotalesRecursivoAscendiente (e, t) {
       var o = this,
                a = 0,
                i = 0,
                r = this.filtroCuentasHermano(t.subCuentaDe);
            i = e ? 1 : i, r.length > 0 ? r.forEach((function (e) {
                e.activo && (i += 1, e.valuar && 4 == e.nivel && (e.valuar = false, e.totalFinal = e.totalBalanza), a += e.totalFinal)
            })) : a += t.totalFinal;
            var s = this.filtroCuentaPadre(t.subCuentaDe);
            s.length > 0 && s.forEach((function (e) {
                e.activo = i > 0, e.totalFinal = a, e.valuar = false, o.calcularTotalesRecursivoAscendiente(e.activo, e)
            }))
   },
   cambiarTotalValuado(e, t) {
       this.calcularValuadoRecursivoDescendiente(e, t), this.calcularValuadoRecursivoAscendiente(e, t)
   },
   calcularValuadoRecursivoDescendiente(e, t) {
     
       var o = this,
                a = 0,
                i = this.filtroSubCuentas(t.numeroCuenta);
            return t.valuar = e, i.length > 0 ? i.forEach((function (t) {
                t.activo && (a += o.calcularValuadoRecursivoDescendiente(e, t))
            })) : a = e ? t.totalBalanza * this.tipoCambio : t.totalBalanza, t.totalFinal = a, a
   },
   calcularValuadoRecursivoAscendiente (e, t) {
       var o = this,
                a = 0,
                i = 0,
                r = this.filtroCuentasHermano(t.subCuentaDe);
            i = e ? 1 : i, r.length > 0 ? r.forEach((function (e) {
                e.activo && (a += parseFloat(e.totalFinal)), e.valuar && (i += 1)
            })) : a += t.totalFinal;
            var s = this.filtroCuentaPadre(t.subCuentaDe);
            s.length > 0 && s.forEach((function (e) {
                e.valuar = i > 0, e.totalFinal = a, o.calcularValuadoRecursivoAscendiente(e.valuar, e)
            }))
   },
   filtroSubCuentas (e) {
       return this.saldos.filter((function (t) {
                return t.subCuentaDe.toLowerCase().indexOf(e.toLowerCase()) > -1
            }))
   },
   filtroCuentasHermano(e) {
            return this.saldos.filter((function (t) {
                return t.subCuentaDe.toLowerCase().indexOf(e.toLowerCase()) > -1
            }))
    },
    filtroCuentaPadre (e) {
            return this.saldos.filter((function (t) {
                return t.numeroCuenta.toLowerCase().indexOf(e.toLowerCase()) > -1
            }))
    },
    activacionCuentasCaptura () {
            var e = this;
            this.saldos.forEach((function (t) {
                if (3 == t.nivel) {
                    var o = e.filtroSubCuentas(t.numeroCuenta);
                    t.totalCaptura > 0 && (t.estatusCaptura = true), o.forEach((function (e) {
                        (t.totalCaptura > 0 || e.totalCaptura > 0) && (e.estatusCaptura = true, t.estatusCaptura = true)
                    }))
                }
            }))
    },
    ObtenerSaldos () {
            var e = this;
            this.$services.ajusteAnualService.ObtenerTotalCuentasCreditosDeudas(this.empresaId, this.ejercicio, this.numeroCuentaPadre, this.periodo, this.toma, this.omite).then((function (t) {
                t.data.key.forEach((function (t) {
                    2 == t.nivel && (e.estatusPadre = t.activo), 3 == t.nivel && (e.tieneHijos = true), e.saldos.push(t)
                })), e.activacionCuentasCaptura(), e.omite = e.omite + e.toma, e.toma = 1
            })).catch((function (e) {
                e.response.status && console.log("Error")
            }))
    },
    countDownChanged(e) {
            this.dismissCountDown = e
    },
    showAlert (e, t) {
            this.mensaje = e, this.tipoAlerta = t, this.mostrarMensaje = true, this.dismissCountDown = this.dismissSecs
    },
    GuardarCambios () {
            var e = this;
            this.$services.ajusteAnualService.ActualizarDetalleCreditosDeudas(this.saldos, this.empresaId, this.ejercicio).then((function (t) {
                e.showAlert(t.data.value, "info")
            })).catch((function (t) {
                500 === t.response.status && e.showAlert(t.response.data.value, "danger")
            }))
    }
  },
  mounted() {
   this.omite = 0,
    this.toma = 1,
     this.$route.params.numeroCuenta && (this.numeroCuentaPadre = this.$route.params.numeroCuenta, this.periodo = this.$route.params.periodo)
     , this.ObtenerSaldos(), this.ObtenerTipocambio(), this.ObtenerParametrosAjusteAnual()
  },
};
</script>

<style>
   
</style>