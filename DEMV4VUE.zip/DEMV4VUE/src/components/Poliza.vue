<template>
  <div>
    <b-container
      class="bv-example-row mb-3 mt-3 border rounded"
      style="border-color: rgb(164, 136, 62) !important; color: #2c3e50"
    >
      <b-row cols="12">
        <b-col
          v-for="periodo in periodos"
          :key="periodo.periodo"
          class="mb-2 mt-5 col-md-6"
        >
          <b-card :title="`${periodo.nombre}`">
            <b-card class="mb-2 mt-2">
              <archivo
                :empresaId="empresaId"
                :ejercicio="ejercicio"
                :periodo="periodo.periodo"
              ></archivo>
            </b-card>

            <b-card v-if="periodo.historial.length > 0" class="mb-2 mt-2">
              <div class="row">
                <div class="col">
                  <h4>Pólizas</h4>
                </div>
              </div>
              <div class="row">
                <div class="col">
                  <p class="card-text">Ultima carga:</p>
                </div>
                <div class="col">
                  <p class="card-text">
                    {{ periodo.historial[0].fechaActualizo }}
                  </p>
                </div>
                <div class="col">
                  <router-link
                    :to="`/detallePoliza/${periodo.periodo}/${empresaId}/${ejercicio}`"
                  >
                    <a
                      href="#"
                      data-periodo="@Model.Periodo"
                      class="btn btn-primary polizas w-100"
                      ><i class="fas fa-file-invoice"></i
                    ></a>
                  </router-link>
                </div>
              </div>
            </b-card>
            <b-card v-if="!historialPolizaCargada">
              <b-spinner label="Loading..."></b-spinner>
            </b-card>

            <b-card v-if="periodo.estatus.length !== 0" class="mb-2 mt-2">
              <div class="row">
                <div class="col">
                  <h4>Estatus carga del archivo</h4>
                </div>
              </div>
              <div class="row">
                <div class="col">
                  <p class="card-text">Estatus</p>
                </div>
                <div class="col">
                  <b-badge v-if="periodo.periodo == mesR" variant="info">{{
                    mensajeNotificacion
                  }}</b-badge>
                  <b-badge v-else variant="info">{{ periodo.estatus }}</b-badge>
                </div>
                <div class="col">
                  <b-button
                    @click="ObtenerHistorialNotificaciones(periodo.periodo)"
                    variant="primary"
                    class="w-100"
                    ><i class="fas fa-exclamation-circle"></i
                  ></b-button>
                </div>
              </div>
            </b-card>
            <b-card v-if="!notificacionCargada">
              <b-spinner label="Loading..."></b-spinner>
            </b-card>
          </b-card>
        </b-col>
      </b-row>

      <b-modal ref="modal-notificaciones" hide-footer title="Historial">
        <b-table
          striped
          hover
          bordered
          :items="estatusNotificaciones"
          :fields="fields"
        ></b-table>
      </b-modal>
    </b-container>
  </div>
</template>

<script>
import Archivo from "./Archivo.vue";

export default {
  name: "Poliza",
  props: {
    empresaId: Number,
    ejercicio: Number,
    tipoReporte: String,
    periodoInicio: Number,
    periodoFin: Number,
    accion: Number,
    periodo: Boolean,
  },
  components: {
    Archivo,
  },
  data() {
    return {
      periodos: [],
      oPeriodos: [],
      mensajeNotificacion: "Sin Notificacion",
      mesAnio: 0,
      fields: [
        { key: "fechaInserto", label: "Fecha" },
        { key: "mensajeCargaUsuario", label: "Estatus" },
        { key: "mensajeError", label: "Mensaje de error" },
      ],
      estatusNotificaciones: [],
      historialPolizaCargada: false,
      notificacionCargada: false,
    };
  },
  methods: {
    ObtenerPeriodos(tipoReporte, periodoInicio, periodoFin, accion, periodo) {
      this.oPeriodos = [];

      const servicioPeriodos = this.$services.polizaService.ObtenerPeriodos(
        tipoReporte,
        periodoInicio,
        periodoFin,
        accion,
        periodo
      );

      Promise.all([servicioPeriodos]).then((listaRespuestas) => {
        listaRespuestas[0].data.forEach((periodo) => {
          const oPeriodo = new Object();
          oPeriodo.periodo = periodo.key;
          oPeriodo.nombre = periodo.value;
          oPeriodo.historial = [];
          oPeriodo.estatus = "";
          this.oPeriodos.push(oPeriodo);
        });

        this.$services.demService
          .ObtenerHistorial(this.empresaId, this.ejercicio)
          .then((r) => {
            let contador = 1;
            this.oPeriodos.forEach((periodo) => {
              r.data.forEach((historial) => {
                if (periodo.periodo == historial.key) {
                  periodo.historial = historial.value.filter(
                    (x) => x.tipoArchivo == "POLIZA"
                  );
                }
              });
              if (this.oPeriodos.length == contador) {
                this.historialPolizaCargada = true;
              }
              contador++;
            });
          });

        let contador2 = 1;
        this.oPeriodos.forEach((periodo) => {
          this.$services.polizaService
            .ObtenerNotificacionesCargaPoliza(
              this.empresaId,
              this.ejercicio,
              periodo.periodo
            )
            .then((r) => {
              var primero = r.data.key[0];
              if (periodo.periodo == primero.periodo) {
                periodo.estatus = primero.mensajeCargaUsuario;
              }
              if (this.oPeriodos.length == contador2) {
                this.notificacionCargada = true;
              }
              contador2++;
            })
            .catch(() => {
              if (this.oPeriodos.length == contador2) {
                this.notificacionCargada = true;
              }
              contador2++;
            });
        });
      });
      this.periodos = this.oPeriodos;
    },
    ObtenerHistorialNotificaciones(periodo) {
      this.$refs["modal-notificaciones"].show();
      this.$services.polizaService
        .ObtenerNotificacionesCargaPoliza(
          this.empresaId,
          this.ejercicio,
          periodo
        )
        .then((r) => {
          this.estatusNotificaciones = r.data.key;
        })
        .catch((r) => {
          console.log(r);
          this.estatusNotificaciones = [];
        });
    },
    Conectar() {
      if (this.$conexionSignalr.state === this.$estadoConexionSignalr) {
        this.$conexionSignalr.invoke("UnirAGrupo", window.rfc, this.ejercicio);
      } else {
        this.$conexionSignalr
          .start()
          .then(() =>
            this.$conexionSignalr.invoke(
              "UnirAGrupo",
              window.rfc,
              this.ejercicio
            )
          );
      }
    },
  },
  computed: {
    notificacion: {
      get() {
        return this.mensajeNotificacion;
      },
      set(value) {
        this.mensajeNotificacion = value;
      },
    },
    mesR: {
      get() {
        return this.mesAnio;
      },
      set(value) {
        this.mesAnio = value;
      },
    },
  },
  mounted() {
    this.Conectar();
    this.$conexionSignalr.onclose(() => this.Conectar());

    this.$conexionSignalr.on(
      "RecibirNotificacion",
      (mensaje, periodoR, filtro) => {
        this.notificacion = mensaje;
        this.mesR = periodoR;
        if (filtro) {
          this.$services.demService
            .ObtenerHistorial(this.empresaId, this.ejercicio)
            .then((r) => {
              let contador = 1;
              this.periodos.forEach((periodo) => {
                r.data.forEach((historial) => {
                  console.log(historial);
                  if (periodo.periodo == historial.key) {
                    periodo.historial = historial.value.filter(
                      (x) => x.tipoArchivo == "POLIZA"
                    );
                  }
                });
                if (this.periodos.length == contador) {
                  this.historialPolizaCargada = true;
                }
                contador++;
              });
            });
        } else {
          let contador2 = 1;
          this.periodos.forEach((periodo) => {
            this.$services.polizaService
              .ObtenerNotificacionesCargaPoliza(
                this.empresaId,
                this.ejercicio,
                periodo.periodo
              )
              .then((r) => {
                var primero = r.data.key[0];
                if (periodo.periodo == primero.periodo) {
                  periodo.estatus = primero.mensajeCargaUsuario;
                }
                if (this.periodos.length == contador2) {
                  this.notificacionCargada = true;
                }
                contador2++;
              })
              .catch(() => {
                if (this.periodos.length == contador2) {
                  this.notificacionCargada = true;
                }
                contador2++;
              });
          });
        }
      }
    );
  },
};
</script>