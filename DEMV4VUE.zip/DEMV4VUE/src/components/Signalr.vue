<template>
  <div>
    <input type="text" v-model="user" />
    <input type="text" v-model="message" />
    <input type="button" id="sendmessage" value="Send" v-on:click="Send" />

    <div v-for="(k, index) in listMessage" :key="index">
      <p>{{ k.name }} : {{ k.message }}</p>
    </div>
  </div>
</template>
<script>
export default {
  name: "Signalr",
  props: {},
  components: {},
  data() {
    return {
      message: "",
      user: "",
      listMessage: [],
    };
  },
  methods: {
    Send() {
      if (this.$conexionSignalr.state === this.$estadoConexionSignalr) {
        this.$conexionSignalr.invoke("EnviarMensaje", this.user, this.message);
      } else {
        this.$conexionSignalr
          .start()
          .then(() =>
            this.$conexionSignalr.invoke(
              "EnviarMensaje",
              this.user,
              this.message
            )
          );
      }
    },
  },
  mounted() {
    /*this.$conexionSignalr.start();
    this.$conexionSignalr.on("RecibirMensaje", (user, data) => {
      
      const insertdata = { name: user, message: data };
      this.listMessage.push(insertdata);
    });*/

     if (this.$conexionSignalr.state === this.$estadoConexionSignalr) {
      this.$conexionSignalr.invoke("UnirAGrupo", "CUPU800825569");
    } else {
      this.$conexionSignalr
        .start()
        .then(() =>
          this.$conexionSignalr.invoke("UnirAGrupo", "CUPU800825569")
        );
    }

    this.$conexionSignalr.on("RecibirNotificacion", mensaje => {
      this.notificacion = mensaje;
      console.log(mensaje);
    });
  },
};
</script>