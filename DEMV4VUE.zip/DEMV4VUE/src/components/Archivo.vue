<template>
  <div>
    <div class="form-group">
      <b-progress
        v-if="barraProgreso"
        :value="valorActualProgress"
        :max="valorMaximoProgress"
        show-progress
        class="mb-3"
      ></b-progress>
    </div>
    <div class="form-group">
      <label class="control-label text-center m-auto px-2" for="Poliza"
        >Archivo de póliza</label
      >
      <div class="input-group">
        <b-form-file ref="archivo" class="form-control mb-2"></b-form-file>
      </div>
      <div v-if="archivoRquerido" class="text-danger">
        El campo Archivo de póliza es requerido
      </div>
      <div v-if="validarTipoArchivo" class="text-danger">
        El campo Archivo de póliza debe ser tipo .xml
      </div>
    </div>
    <div class="form">
      <button v-on:click="SubirArchivo()" class="btn btn-primary">
        Subir archivo
      </button>
    </div>
  </div>
</template>

<script>
export default {
  name: "Archivo",
  props: {
    empresaId: Number,
    ejercicio: Number,
    periodo: Number,
  },
  components: {},
  data() {
    return {
      archivo: "",
      FileChunk: [],
      file: [],
      MaxFileSizeMB: 0,
      BufferChunkSize: 0,
      ReadBuffer_Size: 0,
      FileStreamPos: 0,
      EndPos: 0,
      Size: 0,
      TotalParts: 0,
      PartCount: 0,
      filePath: "",
      promises: [],
      contador: 0,
      percentage: 0,
      rutaArchivo: "",
      FilePartName: "",
      respuestas: [],
      primerRespuesta: null,
      valorMaximoProgress: 100,
      valorActualProgress: 0,
      rfc: "",
      archivoRquerido: false,
      validarTipoArchivo: false,
      barraProgreso: false,
    };
  },
  methods: {
    SubirArchivo() {
      console.log(this.periodo)
      console.log(this.empresaId)
      console.log(this.ejercicio)
      this.barraProgreso = true;
      if (!this.$refs.archivo.files[0]) {
        this.archivoRquerido = true;
      } else {
        this.archivoRquerido = false;
        if (this.$refs.archivo.files[0].type === "text/xml") {
          this.validarTipoArchivo = false;
          this.$services.empresaService
            .ObtenerEmpresaPorId(this.empresaId)
            .then((r) => {
              this.rfc = r.data.key.rfc;
              this.CargarXMLPoliza(
                this.$refs.archivo.files[0],
                this.rfc,
                this.periodo,
                this.empresaId,
                this.ejercicio
              );
            })
            .catch((r) => {
              console.log(r);
            });
        } else {
          this.validarTipoArchivo = true;
        }
      }
    },
    CargarXMLPoliza(TargetFile, rfcEmpresa, periodoCarga, idEmpresa, ejercicio) {
      // the file object itself that we will work with
      this.file = TargetFile;

      console.log(this.file);

      // set up other initial vars
      this.MaxFileSizeMB = 10;
      this.BufferChunkSize = this.MaxFileSizeMB * (1024 * 1024);
      this.ReadBuffer_Size = 10240;
      this.FileStreamPos = 0;
      // set the initial chunk length
      this.EndPos = this.BufferChunkSize;
      this.Size = this.file.size;

      // add to the FileChunk array until we get to the end of the file
      while (this.FileStreamPos < this.Size) {
        // "slice" the file from the starting position/offset, to  the required length
        this.FileChunk.push(this.file.slice(this.FileStreamPos, this.EndPos));
        this.FileStreamPos = this.EndPos; // jump by the amount read
        this.EndPos = this.FileStreamPos + this.BufferChunkSize; // set next chunk length
      }

      // get total number of "files" we will be sending
      this.TotalParts = this.FileChunk.length;
      this.PartCount = 0;
      this.filePath = "";
      this.promises = [];
      this.contador = 0;
      this.percentage = 0;
      this.rutaArchivo = "";

      this.FileChunk.forEach((chunk) => {
        this.PartCount++;
        this.FilePartName =
          this.file.name + ".part_" + this.PartCount + "." + this.TotalParts;

        const cargaXML = this.$services.polizaService.LlamarCargaXMLPoliza(
          chunk,
          this.FilePartName,
          rfcEmpresa,
          idEmpresa,
          this.ejercicio
        );

        this.respuestas.push(cargaXML);

        cargaXML.then((r) => {
          console.log(r);
          this.contador++;
          this.percentage = (this.contador * 100) / this.TotalParts;
          this.valorActualProgress = this.percentage;
        });
      });

      Promise.all(this.respuestas).then((listaRespuestas) => {
        this.$services.polizaService.InicioProcesoPoliza(
          listaRespuestas[0].data.rutaArchivo,
          rfcEmpresa,
          periodoCarga,
          idEmpresa,
          ejercicio
        );
        
        if (this.valorActualProgress === 100) {
          setTimeout(() => {
            this.barraProgreso = false;
            this.$refs.archivo.reset();
          }, 1000);
        }

        //alert("proceso iniciado");
      });
    },
  },
  mounted() {},
};
</script>