import Vue from 'vue'
import VueRouter from 'vue-router'
import App from './App.vue'
import Vuelidate from 'vuelidate'
import services from './services/_index'
import routes from './routes/index'
import { BootstrapVue, IconsPlugin } from 'bootstrap-vue'
import conexionSignalr from './signalr/conexion'


// Global logic methods
Vue.use({
  install(Vue) {
    Object.defineProperty(Vue.prototype, '$services', {
      value: services
    })
  }
})

// Validations
Vue.use(Vuelidate)

// Install BootstrapVue
Vue.use(BootstrapVue)
// Optionally install the BootstrapVue icon components plugin
Vue.use(IconsPlugin)

Vue.config.productionTip = false

import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'

//Router config
Vue.use(VueRouter)
let router = new VueRouter({
  routes
})

Vue.use(conexionSignalr)


new Vue({
  router,
  render: h => h(App),
}).$mount('#app')
